
"""Five equal-area ANYmal C world layouts with distinct walking circuits.

Newton reference implementation for the large-scale robot scene.

The bundled assets/anymal_swarm/anymal_c_walk_layout.json defines five robot/obstacle layouts
and paired 80-waypoint routes. World i uses mode i % 5, so 20 worlds use each mode
four times. All modes share the 10.8 m terrain and 9.9 m electronic boundary.
World display centers are 10.8 m apart, so adjacent terrain edges meet.
Horizontal layout dimensions are compacted; dog sizes and step heights are unchanged.
Horizontal/vertical worlds use separate outbound and return lanes with end turns.
The diagonal mode also separates outbound and return travel. The figure-eight
mode uses two side-by-side routes with five dogs each, staggered crossing arrivals
and velocity-based yielding only for predicted conflicts on the same route.
Only the ring mode continuously circles the center. Look-ahead targets advance
locally, never jump on a timeout. Forward neighbors cause yielding.
World-specific cruising speeds reduce synchronized motion between repeated modes.
Stairs intersect the travel lanes: dogs must physically climb and descend them.
Each world varies the full staircase's height, position and yaw with --layout-seed;
variation preserves tread adjacency and keeps the staircase in the lane.
Falls caused by terrain are allowed. The base wave mesh remains shared.
Invisible electronic boundaries only steer the policy inward: they have no display
or collision geometry and do not clamp, teleport or reset a robot. Impacts or falls may still
carry a robot outside. Different worlds remain physically collision-isolated.
--wander-seed sets the world cruising-speed seed, not solver determinism.
Default: one world, ten robots, external collision, 500 frames, no viewer.
Use --viewer gl for interactive layout review; close the window to stop.
Use --world-count 556 for 5,560 robots once the single-world layout is approved.
--robot-spacing scales horizontal robot placement (3.0 preserves the JSON poses).
Collisions can stop or topple robots; the final check allows this and checks
finite states and terrain penetration instead of requiring uninterrupted walking.
"""

from __future__ import annotations

import json
from argparse import ArgumentParser, Namespace
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
from typing import Any

import numpy as np
import warp as wp

import newton
import newton.examples as examples
import newton.utils

ASSET_REVISION: str = "f8fb7abcbeba2318814a74f3eeb02780ad7925d6"
ROBOTS_PER_WORLD: int = 10
WORLD_MODE_COUNT: int = 5
ROUTE_LENGTH: int = 80
SCENE_ASSETS: Path = Path(__file__).resolve().parent / "assets/anymal_swarm"
LAB_TO_MUJOCO: list[int] = [0, 6, 3, 9, 1, 7, 4, 10, 2, 8, 5, 11]
MUJOCO_TO_LAB: list[int] = [0, 4, 8, 2, 6, 10, 1, 5, 9, 3, 7, 11]


@wp.kernel
def choose_walking_commands(
    q: wp.array[float],
    qd: wp.array[float],
    frame: int,
    seed: int,
    turn_at: float,
    target_limit: float,
    routes: wp.array3d[wp.vec2],
    route_ids: wp.array[int],
    route_centers: wp.array2d[wp.vec2],
    crossing_modes: wp.array[int],
    route_indices: wp.array[int],
    targets: wp.array[wp.vec2],
    commands: wp.array[wp.vec3],
):
    """Choose local-world waypoints and steer inward without changing physics state."""
    robot = wp.tid()  # type: int
    start = robot * 19  # type: int
    position = wp.vec2(q[start], q[start + 1])  # type: wp.vec2
    mode = robot // ROBOTS_PER_WORLD % WORLD_MODE_COUNT  # type: int
    lane = route_ids[robot]  # type: int
    center = route_centers[mode, lane]  # type: wp.vec2
    waypoint = route_indices[robot]  # type: int
    # Dense route points allow a short look-ahead without cutting across the world.
    for _ in range(4):
        target = routes[mode, lane, waypoint]  # type: wp.vec2
        if wp.length(target - position) < 0.65:
            waypoint = (waypoint + 1) % ROUTE_LENGTH  # type: int
    target = routes[mode, lane, waypoint]  # type: wp.vec2
    route_indices[robot] = waypoint
    targets[robot] = target
    # Recovery overrides the steering target only; the route resumes after returning.
    if wp.abs(position[0]) > turn_at or wp.abs(position[1]) > turn_at:
        target = wp.vec2(
            wp.clamp(position[0], -target_limit, target_limit), wp.clamp(position[1], -target_limit, target_limit)
        )  # type: wp.vec2
    rotation = wp.quat(q[start + 3], q[start + 4], q[start + 5], q[start + 6])  # type: wp.quat
    desired = wp.quat_rotate_inv(rotation, wp.vec3(target[0] - position[0], target[1] - position[1], 0.0))  # type: wp.vec3
    heading = wp.atan2(desired[1], desired[0])  # type: float
    random = wp.rand_init(seed, robot // ROBOTS_PER_WORLD)  # type: wp.uint32
    cruise = wp.randf(random, 0.48, 0.55)  # type: float
    speed = cruise * wp.max(0.0, wp.cos(heading))  # type: float
    steering = 0.0  # type: float
    world_start = robot // ROBOTS_PER_WORLD * ROBOTS_PER_WORLD  # type: int
    for local in range(ROBOTS_PER_WORLD):
        neighbor = world_start + local  # type: int
        if neighbor != robot:
            delta = wp.vec3(q[neighbor * 19] - position[0], q[neighbor * 19 + 1] - position[1], 0.0)  # type: wp.vec3
            relative = wp.quat_rotate_inv(rotation, delta)  # type: wp.vec3
            if relative[0] > 0.0 and wp.abs(relative[1]) < 0.8:
                clearance = wp.clamp((relative[0] - 1.05) / 0.7, 0.0, 1.0)  # type: float
                speed = wp.min(speed, cruise * clearance)  # type: float
            if (
                crossing_modes[mode] != 0
                and route_ids[neighbor] == lane
                and wp.dot(position - center, target - position) < 0.0
            ):
                velocity = wp.vec2(qd[robot * 18], qd[robot * 18 + 1])  # type: wp.vec2
                other_velocity = wp.vec2(qd[neighbor * 18], qd[neighbor * 18 + 1])  # type: wp.vec2
                relative_velocity = other_velocity - velocity  # type: wp.vec2
                separation = wp.vec2(delta[0], delta[1])  # type: wp.vec2
                approach_time = wp.clamp(
                    -wp.dot(separation, relative_velocity)
                    / wp.max(wp.dot(relative_velocity, relative_velocity), 0.001),
                    0.0,
                    3.0,
                )  # type: float
                miss_distance = wp.length(separation + relative_velocity * approach_time)  # type: float
                other_position = position + separation  # type: wp.vec2
                has_priority = wp.length(other_position - center) < wp.length(position - center) - 0.15 or (
                    wp.abs(wp.length(other_position - center) - wp.length(position - center)) <= 0.15
                    and neighbor < robot
                )  # type: bool
                if has_priority and approach_time > 0.0 and miss_distance < 0.95 and wp.length(separation) < 3.0:
                    speed = wp.min(speed, cruise * wp.clamp((wp.length(separation) - 1.65) / 1.1, 0.0, 1.0))  # type: float
            distance = wp.length(delta)  # type: float
            if relative[0] > 0.0 and distance < 1.4:
                side = -1.0 if relative[1] >= 0.0 else 1.0  # type: float
                steering = steering + side * 0.3 * (1.0 - distance / 1.4)  # type: float
    if wp.length(target - position) < 0.25:
        speed = 0.0  # type: float
    # Ramp up after landing and limit changes to policy commands, never body state.
    speed = speed * wp.clamp(float(frame) / 50.0, 0.0, 1.0)  # type: float
    yaw_rate = wp.clamp(1.8 * heading + steering, -0.7, 0.7)  # type: float
    previous = commands[robot]  # type: wp.vec3
    forward = wp.min(speed, previous[0] + 0.015)  # type: float
    yaw_rate = wp.clamp(yaw_rate, previous[2] - 0.04, previous[2] + 0.04)  # type: float
    commands[robot] = wp.vec3(forward, 0.0, yaw_rate)


@wp.kernel
def observe_robots(
    q: wp.array[float],
    qd: wp.array[float],
    rest: wp.array[float],
    reorder: wp.array[int],
    previous: wp.array2d[float],
    command: wp.array[wp.vec3],
    observations: wp.array2d[float],
):
    robot = wp.tid()  # type: int
    qc = robot * 19  # type: int
    vc = robot * 18  # type: int
    rotation = wp.quat(q[qc + 3], q[qc + 4], q[qc + 5], q[qc + 6])  # type: wp.quat
    linear = wp.quat_rotate_inv(rotation, wp.vec3(qd[vc], qd[vc + 1], qd[vc + 2]))  # type: wp.vec3
    angular = wp.quat_rotate_inv(rotation, wp.vec3(qd[vc + 3], qd[vc + 4], qd[vc + 5]))  # type: wp.vec3
    gravity = wp.quat_rotate_inv(rotation, wp.vec3(0.0, 0.0, -1.0))  # type: wp.vec3
    for axis in range(3):
        observations[robot, axis] = linear[axis]
        observations[robot, 3 + axis] = angular[axis]
        observations[robot, 6 + axis] = gravity[axis]
        observations[robot, 9 + axis] = command[robot][axis]
    for joint in range(12):
        index = reorder[joint]  # type: int
        observations[robot, 12 + joint] = q[qc + 7 + index] - rest[index]
        observations[robot, 24 + joint] = qd[vc + 6 + index]
        observations[robot, 36 + joint] = previous[robot, joint]


@wp.kernel
def apply_actions(
    action: wp.array2d[float],
    rest: wp.array[float],
    reorder: wp.array[int],
    targets: wp.array[float],
    previous: wp.array2d[float],
):
    robot, coordinate = wp.tid()  # type: tuple[int, int]
    target = 1.0 if coordinate == 6 else 0.0  # type: float
    if coordinate >= 7:
        joint = coordinate - 7  # type: int
        target = rest[joint] + 0.5 * action[robot, reorder[joint]]  # type: float
    targets[robot * 19 + coordinate] = target
    if coordinate < 12:
        previous[robot, coordinate] = action[robot, coordinate]


def make_builder() -> newton.ModelBuilder:
    """Register the same MuJoCo schema on each scene assembly level."""
    builder: newton.ModelBuilder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    return builder


def make_robot(asset: Path) -> newton.ModelBuilder:
    """Build the reference robot and verify the pinned mass properties."""
    robot: newton.ModelBuilder = make_builder()
    robot.default_joint_cfg: newton.ModelBuilder.JointDofConfig = newton.ModelBuilder.JointDofConfig(
        armature=0.06, limit_ke=1.0e3, limit_kd=1.0e1
    )
    robot.default_shape_cfg.ke: float = 5.0e4
    robot.default_shape_cfg.kd: float = 5.0e2
    robot.default_shape_cfg.kf: float = 1.0e3
    robot.default_shape_cfg.mu: float = 0.75
    robot.add_urdf(
        str(asset / "urdf/anymal.urdf"),
        xform=wp.transform(wp.vec3(0.0, 0.0, 0.62), wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), wp.pi * 0.5)),
        floating=True,
        enable_self_collisions=False,
        collapse_fixed_joints=True,
        ignore_inertial_definitions=False,
    )
    inertial_path: Path = (
        Path(__file__).resolve().parent / "assets/anymal_swarm/anymal_c_inertials.v1.6.json"
    )
    inertials: dict[str, Any] = json.loads(inertial_path.read_text())
    expected_files: dict[str, str] = {
        "urdf/anymal.urdf": "source_urdf_sha256",
        "rl_policies/anymal_walking_policy_physx.onnx": "source_policy_sha256",
    }
    relative: str
    key: str
    for relative, key in expected_files.items():
        content: bytes = (asset / relative).read_bytes()
        if relative.endswith(".urdf"):
            # Newton's Git asset checkout may use Windows line endings.
            content: bytes = content.replace(b"\r\n", b"\n")
        if sha256(content).hexdigest() != inertials[key]:
            raise ValueError(f"Walking asset checksum differs: {relative}")
    bodies: dict[str, Any] = {item["label"].rsplit("/", 1)[-1]: item for item in inertials["bodies"]}
    body: int
    label: str
    for body, label in enumerate(robot.body_label):
        source: dict[str, Any] = bodies[label.rsplit("/", 1)[-1]]
        if not np.isclose(robot.body_mass[body], source["mass"]) or not np.allclose(
            robot.body_com[body], source["com"]
        ):
            raise ValueError(f"Walking asset mass/COM differs: {label}")
        if not np.allclose(np.asarray(robot.body_inertia[body]).reshape(3, 3), source["inertia"], atol=1.0e-6):
            raise ValueError(f"Newton imported inertia differs from the pinned reference: {label}")
    joint: int
    for joint, label in enumerate(robot.joint_label):
        name: str = label.rsplit("/", 1)[-1]
        if name.endswith("_HAA"):
            robot.joint_q[robot.joint_q_start[joint]]: float = 0.0
        elif name.endswith("_HFE"):
            robot.joint_q[robot.joint_q_start[joint]]: float = -0.4 if name.startswith(("RH", "LH")) else 0.4
        elif name.endswith("_KFE"):
            robot.joint_q[robot.joint_q_start[joint]]: float = 0.8 if name.startswith(("RH", "LH")) else -0.8
    if robot.joint_dof_count != 18 or robot.joint_coord_count != 19:
        raise ValueError("Expected one free base and twelve driven joints per robot")
    robot.body_q[robot.joint_child[0]]: wp.transform = wp.transform_identity()
    dof: int
    for dof in range(robot.joint_dof_count):
        robot.joint_target_ke[dof]: float = 150.0
        robot.joint_target_kd[dof]: float = 5.0
        robot.joint_target_mode[dof]: int = newton.JointTargetMode.POSITION
    return robot


def make_world(
    robot: newton.ModelBuilder,
    terrain: newton.Mesh,
    layout: dict[str, Any],
    mode: dict[str, Any],
    robot_spacing: float,
) -> newton.ModelBuilder:
    """Assemble one scene variant with the shared topology and physical materials."""
    world: newton.ModelBuilder = make_builder()
    poses: list[list[float]] = mode["robots"]
    if len(poses) != ROBOTS_PER_WORLD or not np.isfinite(poses).all():
        raise ValueError("The layout must contain ten finite x/y/yaw poses")
    index: int
    placement: list[float]
    for index, placement in enumerate(poses):
        offset: wp.vec3 = wp.vec3(
            placement[0] * robot_spacing / 3.0,
            placement[1] * robot_spacing / 3.0,
            layout["spawn_height_offset"],
        )
        # The imported robot already has a +90-degree base yaw.
        rotation: wp.quat = wp.quat_from_axis_angle(
            wp.vec3(0.0, 0.0, 1.0), float(np.deg2rad(placement[2])) - wp.pi * 0.5
        )
        world.add_builder(robot, xform=wp.transform(offset, rotation), label_prefix=f"robot_{index}/")
    world.default_shape_cfg.ke: float = 5.0e4
    world.default_shape_cfg.kd: float = 5.0e2
    world.default_shape_cfg.kf: float = 1.0e3
    world.default_shape_cfg.mu: float = 0.75
    # This mesh participates in external collision, including headless/test runs.
    world.add_shape_mesh(
        body=-1,
        mesh=terrain,
        scale=wp.vec3(layout["terrain_horizontal_scale"], layout["terrain_horizontal_scale"], 1.0),
        color=(0.34, 0.42, 0.36),
        xform=wp.transform(wp.vec3(*layout["terrain_translation"]), wp.quat_identity()),
        cfg=replace(world.default_shape_cfg, density=0.0, has_shape_collision=True),
    )
    step_index: int
    step: dict[str, Any]
    for step_index, step in enumerate(mode["stairs"]):
        world.add_shape_box(
            body=-1,
            xform=wp.transform(
                wp.vec3(step["x"], step["y"], step["height"] * 0.5),
                wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(np.deg2rad(step["yaw"]))),
            ),
            hx=step["width"] * 0.5,
            hy=step["length"] * 0.5,
            hz=step["height"] * 0.5,
            cfg=replace(world.default_shape_cfg, density=0.0, has_shape_collision=True),
            color=tuple(step["color"]),
            label=f"terrain_step_{step_index}",
        )
    world.add_ground_plane()
    return world


def world_stairs(mode: dict[str, Any], variation: dict[str, Any], seed: int, world: int) -> list[dict[str, Any]]:
    """Vary an entire staircase coherently so neighboring treads remain adjacent."""
    random: np.random.Generator = np.random.default_rng(np.random.SeedSequence([seed, world]))
    height_scale: float = float(random.uniform(*variation["height_scale"]))
    offset: np.ndarray = random.uniform(-variation["offset_m"], variation["offset_m"], 2)
    yaw: float = float(random.uniform(-variation["yaw_degrees"], variation["yaw_degrees"]))
    angle: float = float(np.deg2rad(yaw))
    rotation: np.ndarray = np.asarray([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
    origin: np.ndarray = np.mean([[step["x"], step["y"]] for step in mode["stairs"]], axis=0)
    stairs: list[dict[str, Any]] = []
    step: dict[str, Any]
    for step in mode["stairs"]:
        position: np.ndarray = origin + offset + rotation @ (np.asarray([step["x"], step["y"]]) - origin)
        stairs.append(
            dict(
                step,
                x=float(position[0]),
                y=float(position[1]),
                yaw=step["yaw"] + yaw,
                height=step["height"] * height_scale,
            )
        )
    return stairs


def stair_spawn_lift(x: float, y: float, stairs: list[dict[str, Any]]) -> float:
    """Place robots above nearby treads at reset, avoiding initial interpenetration."""
    lift: float = 0.0
    step: dict[str, Any]
    for step in stairs:
        angle: float = float(np.deg2rad(step["yaw"]))
        dx: float = x - step["x"]
        dy: float = y - step["y"]
        local_x: float = float(np.cos(angle) * dx + np.sin(angle) * dy)
        local_y: float = float(-np.sin(angle) * dx + np.cos(angle) * dy)
        # Account for the full robot footprint, not only its root point.
        if abs(local_x) < step["width"] * 0.5 + 0.75 and abs(local_y) < step["length"] * 0.5 + 0.75:
            lift: float = max(lift, float(step["height"]))
    return lift


class Scenario:
    """Batched walking reference using only Newton runtime objects."""

    def __init__(self, viewer: Any, args: Namespace) -> None:
        from warp_nn.runtime import OnnxRuntime  # noqa: PLC0415 - optional policy runtime

        if args.world_count < 1 or not np.isfinite(args.robot_spacing) or args.robot_spacing <= 0.0:
            raise ValueError("world-count and robot-spacing must be positive")
        if args.layout_seed < 0:
            raise ValueError("layout-seed must be nonnegative")
        if not newton.use_coord_layout_targets:
            raise ValueError("This reference requires Newton's coordinate-layout joint_target_q")
        self.args: Namespace = args
        self.viewer: Any = viewer
        self.robot_count: int = args.world_count * ROBOTS_PER_WORLD
        self.frame_dt: float = 1.0 / 50.0
        self.sim_substeps: int = 4
        self.sim_dt: float = self.frame_dt / self.sim_substeps
        self.sim_time: float = 0.0
        self.frame_index: int = 0
        print(f"Loading Newton reference assets for {self.robot_count} robots...", flush=True)
        asset: Path = Path(__file__).resolve().parent / "assets/robots/anybotics_anymal_c"
        robot: newton.ModelBuilder = make_robot(asset)
        layout: dict[str, Any] = json.loads(
            (SCENE_ASSETS / "anymal_c_walk_layout.json").read_text()
        )
        modes: list[dict[str, Any]] = layout["world_modes"]
        if len(modes) != WORLD_MODE_COUNT:
            raise ValueError("Expected exactly five world modes")
        fence: dict[str, float] = layout["electronic_fence"]
        self.fence_half_extent: float = float(fence["half_extent"])
        self.fence_turn_at: float = self.fence_half_extent - float(fence["turn_margin"])
        self.target_limit: float = float(fence["target_half_extent"])
        if not 0.0 < self.target_limit < self.fence_turn_at < self.fence_half_extent:
            raise ValueError("Expected target area inside turning area inside the electronic fence")
        route_data: np.ndarray = np.asarray([mode["routes"] for mode in modes], dtype=np.float32)
        if route_data.shape != (WORLD_MODE_COUNT, 2, ROUTE_LENGTH, 2) or not np.isfinite(route_data).all():
            raise ValueError("Each world mode needs two routes of 80 finite 2D waypoints")
        if np.any(np.abs(route_data) > self.target_limit):
            raise ValueError("Route waypoints must be inside the target area")
        mode: dict[str, Any]
        for mode in modes:
            poses: np.ndarray = np.asarray(mode["robots"], dtype=np.float32)
            if poses.shape != (ROBOTS_PER_WORLD, 3) or not np.isfinite(poses).all():
                raise ValueError("Each world mode needs ten finite x/y/yaw robot poses")
            if np.any(np.abs(poses[:, :2] * args.robot_spacing / 3.0) >= self.fence_turn_at):
                raise ValueError("Initial robot positions must stay inside the turning area")
            if len(mode["stairs"]) != 5:
                raise ValueError("Each world mode must contain five box obstacles")
        terrain_data: Any
        with np.load(SCENE_ASSETS / layout["terrain_asset"], allow_pickle=False) as terrain_data:
            terrain: newton.Mesh = newton.Mesh(terrain_data["vertices"], terrain_data["indices"], compute_inertia=False)
        templates: list[newton.ModelBuilder] = [
            make_world(robot, terrain, layout, mode, args.robot_spacing)
            for mode in modes[: min(args.world_count, WORLD_MODE_COUNT)]
        ]
        builder: newton.ModelBuilder = make_builder()
        print(f"Building {args.world_count} worlds with five cycling layouts...", flush=True)
        builder.replicate(templates[0], args.world_count)
        # Preserve batched topology replication, then author only variant properties
        # before finalize. Robot topology, mesh assets, masses and materials stay shared.
        variant_fields: tuple[str, ...] = (
            "joint_q",
            "body_q",
            "shape_transform",
            "shape_scale",
            "shape_color",
            "shape_collision_radius",
        )
        world_index: int
        field: str
        for world_index in range(args.world_count):
            template: newton.ModelBuilder = templates[world_index % WORLD_MODE_COUNT]
            for field in variant_fields:
                values: list[Any] = getattr(template, field)
                destination: list[Any] = getattr(builder, field)
                begin: int = world_index * len(values)
                destination[begin : begin + len(values)] = values
        # The batched topology stays identical; only authored per-world geometry
        # and initial spawn clearance vary. No solver or collision filtering changes.
        for world_index in range(args.world_count):
            template: newton.ModelBuilder = templates[world_index % WORLD_MODE_COUNT]
            mode: dict[str, Any] = modes[world_index % WORLD_MODE_COUNT]
            stairs: list[dict[str, Any]] = world_stairs(mode, layout["stair_variation"], args.layout_seed, world_index)
            step_index: int
            step: dict[str, Any]
            for step_index, step in enumerate(stairs):
                local_shape: int = template.shape_label.index(f"terrain_step_{step_index}")
                shape: int = world_index * template.shape_count + local_shape
                builder.shape_transform[shape]: wp.transform = wp.transform(
                    wp.vec3(step["x"], step["y"], step["height"] * 0.5),
                    wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(np.deg2rad(step["yaw"]))),
                )
                builder.shape_scale[shape]: wp.vec3 = wp.vec3(
                    step["width"] * 0.5, step["length"] * 0.5, step["height"] * 0.5
                )
                builder.shape_collision_radius[shape]: float = float(np.linalg.norm(builder.shape_scale[shape]))
            robot_index: int
            for robot_index in range(ROBOTS_PER_WORLD):
                coordinate: int = world_index * template.joint_coord_count + robot_index * 19
                lift: float = stair_spawn_lift(builder.joint_q[coordinate], builder.joint_q[coordinate + 1], stairs)
                builder.joint_q[coordinate + 2]: float = builder.joint_q[coordinate + 2] + lift
                body_index: int
                bodies_per_robot: int = template.body_count // ROBOTS_PER_WORLD
                for body_index in range(bodies_per_robot):
                    body: int = world_index * template.body_count + robot_index * bodies_per_robot + body_index
                    transform: wp.transform = wp.transform(*builder.body_q[body])
                    builder.body_q[body]: wp.transform = wp.transform(
                        wp.vec3(transform.p[0], transform.p[1], transform.p[2] + lift), transform.q
                    )
        self.world_modes: tuple[str, ...] = tuple(modes[i % WORLD_MODE_COUNT]["name"] for i in range(args.world_count))
        self.model: newton.Model = builder.finalize(device=args.device)
        self.device: wp.context.Device = self.model.device
        print("Preparing Newton MuJoCo, external collisions and viewer...", flush=True)
        self.solver: newton.solvers.SolverMuJoCo = newton.solvers.SolverMuJoCo(
            self.model,
            separate_worlds=True,
            use_mujoco_cpu=False,
            use_mujoco_contacts=False,
            solver="newton",
            integrator="implicitfast",
            cone="pyramidal",
            impratio=1.0,
            iterations=100,
            ls_iterations=50,
            tolerance=1.0e-8,
            ls_tolerance=0.01,
            update_data_interval=1,
            include_sites=True,
            enable_multiccd=False,
            disable_contacts=False,
            disable_sensors=True,
            njmax=1024,
            nconmax=4096,
            deterministic=wp.DeterministicMode.GPU_TO_GPU if args.deterministic else None,
        )
        self.viewer.set_model(self.model)
        if args.viewer != "null":
            self.viewer.set_world_offsets((fence["world_display_spacing"], fence["world_display_spacing"], 0.0))
        if args.viewer == "gl":
            offsets: np.ndarray = self.viewer.world_offsets.numpy()
            center: np.ndarray = (offsets.min(axis=0) + offsets.max(axis=0)) * 0.5
            terrain_width: float = layout["terrain_generator"]["block_size"][0] * layout["terrain_horizontal_scale"]
            camera_scale: float = max(0.9, float(np.ptp(offsets[:, :2], axis=0).max() + terrain_width) / 12.0)
            self.viewer.set_camera(
                pos=wp.vec3(*(center + np.asarray([8.0, -11.0, 6.5]) * camera_scale)), pitch=-24.0, yaw=126.0
            )
        self.state_0: newton.State = self.model.state()
        self.state_1: newton.State = self.model.state()
        self.control: newton.Control = self.model.control()
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        newton.eval_fk(self.model, self.state_1.joint_q, self.state_1.joint_qd, self.state_1)
        self.collision_pipeline: newton.CollisionPipeline = newton.CollisionPipeline(
            self.model, broad_phase="explicit", max_triangle_pairs=8_000_000, deterministic=args.deterministic
        )
        self.contacts: newton.Contacts = self.collision_pipeline.contacts()
        if self.model.joint_dof_count != self.robot_count * 18:
            raise ValueError("Unexpected batched robot DOF layout")
        if self.control.joint_target_q.shape != (self.robot_count * 19,):
            raise ValueError("Expected 19 target coordinates per robot")
        self.initial_positions: np.ndarray = self.state_0.joint_q.numpy().reshape(self.robot_count, 19).copy()
        self.rest: wp.array = wp.array(self.initial_positions[0, 7:], dtype=wp.float32, device=self.device)
        self.lab_order: wp.array = wp.array(LAB_TO_MUJOCO, dtype=wp.int32, device=self.device)
        self.mujoco_order: wp.array = wp.array(MUJOCO_TO_LAB, dtype=wp.int32, device=self.device)
        self.observations: wp.array = wp.zeros((self.robot_count, 48), dtype=wp.float32, device=self.device)
        self.previous_action: wp.array = wp.zeros((self.robot_count, 12), dtype=wp.float32, device=self.device)
        self.command: wp.array = wp.zeros(self.robot_count, dtype=wp.vec3, device=self.device)
        self.waypoints: wp.array = wp.zeros(self.robot_count, dtype=wp.vec2, device=self.device)
        self.routes: wp.array = wp.array(route_data, dtype=wp.vec2, device=self.device)
        self.route_centers: wp.array = wp.array(route_data.mean(axis=2), dtype=wp.vec2, device=self.device)
        route_starts: np.ndarray = np.asarray(
            [
                modes[w % WORLD_MODE_COUNT]["route_starts"][r]
                for w in range(args.world_count)
                for r in range(ROBOTS_PER_WORLD)
            ],
            dtype=np.int32,
        )
        self.route_ids: wp.array = wp.array(
            [
                modes[w % WORLD_MODE_COUNT]["robot_routes"][r]
                for w in range(args.world_count)
                for r in range(ROBOTS_PER_WORLD)
            ],
            dtype=wp.int32,
            device=self.device,
        )
        self.crossing_modes: wp.array = wp.array(
            [int(mode["crossing"]) for mode in modes], dtype=wp.int32, device=self.device
        )
        self.route_indices: wp.array = wp.array(route_starts, dtype=wp.int32, device=self.device)
        print("Preparing batched walking policy and simulation graph...", flush=True)
        self.policy: Any = OnnxRuntime(
            str(asset / "rl_policies/anymal_walking_policy_physx.onnx"),
            device=self.device,
            batch_size=self.robot_count,
            input_batch_axes=0,
            requires_grad=False,
        )
        self.policy_input: str = self.policy.input_names[0]
        self.policy_output: str = self.policy.output_names[0]
        warm_action: wp.array = self.policy({self.policy_input: self.observations})[self.policy_output]
        if warm_action.shape != (self.robot_count, 12):
            raise ValueError("Walking policy did not produce one action vector per robot")
        self.graph: Any = None
        if self.device.is_cuda and not args.disable_graph and not args.deterministic:
            with wp.ScopedCapture(device=self.device) as capture:
                self.simulate()
            self.graph: Any = capture.graph
        print(
            f"ANYmal C walk: {args.world_count} worlds x {ROBOTS_PER_WORLD} robots = {self.robot_count}; "
            f"{self.robot_count * 18} effective DOFs; external contacts; Newton GPU MuJoCo; warp-nn",
            flush=True,
        )

    def simulate(self) -> None:
        _substep: int
        for _substep in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.collision_pipeline.collide(self.state_0, self.contacts)
            self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self) -> None:
        wp.launch(
            choose_walking_commands,
            dim=self.robot_count,
            inputs=[
                self.state_0.joint_q,
                self.state_0.joint_qd,
                self.frame_index,
                self.args.wander_seed,
                self.fence_turn_at,
                self.target_limit,
                self.routes,
                self.route_ids,
                self.route_centers,
                self.crossing_modes,
                self.route_indices,
                self.waypoints,
                self.command,
            ],
            device=self.device,
        )
        wp.launch(
            observe_robots,
            dim=self.robot_count,
            inputs=[
                self.state_0.joint_q,
                self.state_0.joint_qd,
                self.rest,
                self.lab_order,
                self.previous_action,
                self.command,
                self.observations,
            ],
            device=self.device,
        )
        action: wp.array = self.policy({self.policy_input: self.observations})[self.policy_output]
        wp.launch(
            apply_actions,
            dim=(self.robot_count, 19),
            inputs=[action, self.rest, self.mujoco_order, self.control.joint_target_q, self.previous_action],
            device=self.device,
        )
        if self.graph is None:
            self.simulate()
        else:
            wp.capture_launch(self.graph)
        self.sim_time: float = self.sim_time + self.frame_dt
        self.frame_index: int = self.frame_index + 1

    def render(self) -> None:
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self) -> None:
        if self.model.world_count != self.args.world_count or self.model.joint_dof_count != self.robot_count * 18:
            raise AssertionError("World or robot DOF count differs from the requested layout")
        field: str
        for field in ("body_q", "body_qd", "joint_q", "joint_qd"):
            if not np.isfinite(getattr(self.state_0, field).numpy()).all():
                raise AssertionError(f"Nonfinite Newton state: {field}")
        q: np.ndarray = self.state_0.joint_q.numpy().reshape(self.robot_count, 19)
        if not np.isfinite(self.previous_action.numpy()).all() or np.any(q[:, 2] < -0.10):
            raise AssertionError("A policy action is nonfinite or a robot root passed below the ground")


def main() -> None:
    parser: ArgumentParser = examples.create_parser()
    parser.add_argument("--world-count", type=int, default=1)
    parser.add_argument("--robot-spacing", type=float, default=3.0)
    parser.add_argument("--disable-graph", action="store_true")
    parser.add_argument(
        "--layout-seed", type=int, default=42, help="Seed for per-world staircase height and placement."
    )
    parser.add_argument(
        "--wander-seed", type=int, default=42, help="Seed for slightly different cruising speeds between worlds."
    )
    parser.add_argument(
        "--deterministic",
        action="store_true",
        help="Use solver-scoped GPU_TO_GPU and sorted external contacts; run eagerly on CUDA.",
    )
    parser.set_defaults(num_frames=500, viewer="null", device="cuda:0")
    viewer: Any
    args: Namespace
    viewer, args = examples.init(parser)
    examples.run(Scenario(viewer, args), args)


if __name__ == "__main__":
    main()
