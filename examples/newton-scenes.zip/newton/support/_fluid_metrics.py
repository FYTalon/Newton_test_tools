"""Warp CUDA CIC metrics for the Newton single-box reference example.

Uses the same fixed, cell-centred CIC and SI force protocol as the candidate.
This helper imports no candidate package or physics implementation.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import ArrayLike, NDArray
import warp as wp

_REFERENCE_KEYS: tuple[str, ...] = (
    "floor_force_method",
    "floor_force_sign",
    "scene_protocol",
    "volume_method",
    "diagnostic_h_m",
    "diagnostic_origin_m",
    "total_mass_kg",
    "initial_state_sha256",
)


def _positions(value: ArrayLike) -> NDArray[np.float64]:
    result = np.asarray(value, dtype=np.float64)
    if result.ndim != 2 or result.shape[1] != 3:
        raise ValueError("positions must have shape (N, 3)")
    return result


def _mask(value: ArrayLike | None, count: int) -> NDArray[np.bool_]:
    result = np.ones(count, dtype=bool) if value is None else np.asarray(value, dtype=bool)
    if result.shape != (count,):
        raise ValueError("active_mask must have shape (N,)")
    return result


@wp.kernel
def _deposit_cic(
    positions: wp.array(dtype=wp.vec3),
    particle_volumes: wp.array(dtype=wp.float64),
    particle_flags: wp.array(dtype=wp.int32),
    active_bit: int,
    origin: wp.vec3d,
    inv_h: wp.float64,
    lo_x: int,
    lo_y: int,
    lo_z: int,
    dim_x: int,
    dim_y: int,
    dim_z: int,
    grid: wp.array(dtype=wp.float64),
    invalid: wp.array(dtype=wp.int32),
):
    tid = wp.tid()
    p = positions[tid]
    if not wp.isfinite(p[0]) or not wp.isfinite(p[1]) or not wp.isfinite(p[2]):
        if (particle_flags[tid] & active_bit) != 0:
            wp.atomic_add(invalid, 1, 1)
        else:
            wp.atomic_add(invalid, 2, 1)
        return
    if (particle_flags[tid] & active_bit) == 0:
        return
    x = (wp.float64(p[0]) - origin[0]) * inv_h - wp.float64(0.5)
    y = (wp.float64(p[1]) - origin[1]) * inv_h - wp.float64(0.5)
    z = (wp.float64(p[2]) - origin[2]) * inv_h - wp.float64(0.5)
    if wp.abs(x) > wp.float64(1.0e9) or wp.abs(y) > wp.float64(1.0e9) or wp.abs(z) > wp.float64(1.0e9):
        wp.atomic_add(invalid, 0, 1)
        return
    ix = int(wp.floor(x))
    iy = int(wp.floor(y))
    iz = int(wp.floor(z))
    if ix < lo_x or ix + 1 >= lo_x + dim_x or iy < lo_y or iy + 1 >= lo_y + dim_y or iz < lo_z or iz + 1 >= lo_z + dim_z:
        wp.atomic_add(invalid, 0, 1)
        return
    fx = x - wp.float64(ix)
    fy = y - wp.float64(iy)
    fz = z - wp.float64(iz)
    vol = particle_volumes[tid]
    for a in range(2):
        wx = fx if a == 1 else wp.float64(1.0) - fx
        for b in range(2):
            wy = fy if b == 1 else wp.float64(1.0) - fy
            for c in range(2):
                wz = fz if c == 1 else wp.float64(1.0) - fz
                idx = (((ix + a - lo_x) * dim_y + (iy + b - lo_y)) * dim_z + (iz + c - lo_z))
                wp.atomic_add(grid, idx, vol * wx * wy * wz)


class CICEffectiveVolume:
    """Warp CUDA CIC with a dynamically expanding physical lattice.

    The exact saturated rest-volume definition is preserved. The device
    lattice grows if a particle leaves its cached extent. Out-of-memory
    ranges fail explicitly; no particle contribution is silently clipped.
    """

    def __init__(
        self, positions: ArrayLike, rest_volumes: ArrayLike, h: float,
        origin: ArrayLike = (0.0, 0.0, 0.0),
        active_mask: ArrayLike | None = None,
        margin_m: float = 3.0, device: str = "cuda:0",
        max_cells: int = 3_000_000,
    ) -> None:
        initial = _positions(positions)
        self.h = float(h)
        self.origin = np.array(origin, dtype=np.float64, copy=True)
        self.rest_volumes = np.array(rest_volumes, dtype=np.float64, copy=True)
        if not np.isfinite(self.h) or self.h <= 0:
            raise ValueError("h must be finite and positive")
        if self.origin.shape != (3,) or not np.isfinite(self.origin).all():
            raise ValueError("origin must be finite three-vector")
        if self.rest_volumes.shape != (len(initial),):
            raise ValueError("rest_volumes must have shape (N,)")
        if not np.isfinite(self.rest_volumes).all() or np.any(self.rest_volumes < 0):
            raise ValueError("rest_volumes must be finite and nonnegative")
        if not np.isfinite(margin_m) or margin_m < 0:
            raise ValueError("margin_m must be finite and >= 0")
        self._margin_m = float(margin_m)
        self._max_cells = int(max_cells)
        if self._max_cells <= 0:
            raise ValueError("max_cells must be > 0")
        self.initial_active_mask = _mask(active_mask, len(initial)).copy()
        if not self.initial_active_mask.any():
            raise ValueError("initial effective volume must be positive")
        if not np.isfinite(initial[self.initial_active_mask]).all():
            raise ValueError("nonfinite active particle positions")
        self.origin.flags.writeable = False
        self.rest_volumes.flags.writeable = False
        self.initial_active_mask.flags.writeable = False
        self._device = wp.get_device(device)
        self._wp_volumes = wp.array(self.rest_volumes, dtype=wp.float64, device=self._device)
        self._invalid = wp.zeros(3, dtype=wp.int32, device=self._device)
        self._origin_wp = wp.vec3d(*[float(v) for v in self.origin])
        self._set_window(initial, self.initial_active_mask, preserve=False)
        self.initial_volume_m3 = None
        self.initial_volume_m3 = float(self.measure(initial)["effective_volume_m3"])
        if self.initial_volume_m3 <= 0:
            raise ValueError("initial effective volume must be positive")

    def _set_window(self, positions, active, preserve):
        xyz = (np.asarray(positions, dtype=np.float64)[active] - self.origin) / self.h - 0.5
        if not np.isfinite(xyz).all() or np.any(np.abs(xyz) >= 1.0e9):
            raise ValueError("particle coordinates exceed safe Warp CIC lattice range")
        lo = np.floor(xyz.min(axis=0) - self._margin_m / self.h).astype(np.int64)
        hi = np.ceil(xyz.max(axis=0) + self._margin_m / self.h).astype(np.int64) + 2
        if preserve:
            lo = np.minimum(lo, np.asarray(self._bounds_lo))
            hi = np.maximum(hi, np.asarray(self._bounds_lo) + np.asarray(self._dims))
        dims = hi - lo
        cells = int(np.prod(dims, dtype=np.int64))
        if cells <= 0 or cells > self._max_cells:
            raise ValueError(
                f"Warp CIC needs {cells} lattice cells; max_cells={self._max_cells}. "
                "Aborting rather than clipping the volume."
            )
        self._bounds_lo = tuple(int(v) for v in lo)
        self._dims = tuple(int(v) for v in dims)
        self._grid = wp.zeros(cells, dtype=wp.float64, device=self._device)

    def measure_gpu(self, positions: wp.array, particle_flags: wp.array, active_bit: int) -> dict[str, Any]:
        if not isinstance(positions, wp.array) or positions.dtype != wp.vec3 or len(positions) != len(self.rest_volumes):
            raise ValueError("Expected Warp vec3 particle positions with matching population")
        if not isinstance(particle_flags, wp.array) or len(particle_flags) != len(positions):
            raise ValueError("Expected matching Warp particle flags")
        if int(active_bit) <= 0:
            raise ValueError("active_bit must be positive")
        for attempt in range(2):
            self._grid.zero_()
            self._invalid.zero_()
            wp.launch(
                _deposit_cic, dim=len(positions),
                inputs=[
                    positions, self._wp_volumes, particle_flags, int(active_bit),
                    self._origin_wp, wp.float64(1.0 / self.h),
                    *self._bounds_lo, *self._dims, self._grid, self._invalid,
                ],
                device=self._device,
            )
            status = self._invalid.numpy()
            if int(status[1]):
                raise ValueError("nonfinite active particle positions")
            if int(status[0]):
                active = (particle_flags.numpy() & int(active_bit)) != 0
                if not np.any(active):
                    break
                self._set_window(positions.numpy(), active, preserve=True)
                continue
            break
        else:
            raise ValueError("Warp CIC window failed to cover all active particles")
        values = self._grid.numpy()
        active = (particle_flags.numpy() & int(active_bit)) != 0
        effective = float(np.minimum(values, self.h ** 3).sum(dtype=np.float64))
        result = {
            "effective_volume_m3": effective,
            "deposited_volume_m3": float(values.sum(dtype=np.float64)),
            "active_rest_volume_m3": float(self.rest_volumes[active].sum(dtype=np.float64)),
            "inactive_rest_volume_m3": float(self.rest_volumes[~active].sum(dtype=np.float64)),
            "active_count": int(active.sum()),
            "inactive_count": int((~active).sum()),
            "nonfinite_count": int(status[1] + status[2]),
            "inactive_nonfinite_count": int(status[2]),
            "occupied_cell_count": int(np.count_nonzero(values)),
        }
        if self.initial_volume_m3 is not None:
            result["initial_effective_volume_m3"] = self.initial_volume_m3
            result["volume_ratio"] = effective / self.initial_volume_m3
        return result

    def measure(self, positions: ArrayLike, active_mask: ArrayLike | None = None) -> dict[str, Any]:
        """Host-array compatibility entrypoint; CIC deposition stays on GPU."""
        current = _positions(positions)
        if len(current) != len(self.rest_volumes):
            raise ValueError("particle count changed")
        active = self.initial_active_mask if active_mask is None else _mask(active_mask, len(current))
        wp_positions = wp.array(np.asarray(current, dtype=np.float32), dtype=wp.vec3, device=self._device)
        wp_flags = wp.array(active.astype(np.int32), dtype=wp.int32, device=self._device)
        return self.measure_gpu(wp_positions, wp_flags, 1)

    def evaluate(self, positions: ArrayLike, active_mask: ArrayLike | None = None) -> dict[str, Any]:
        return self.measure(positions, active_mask)

def _impulse(value: ArrayLike) -> NDArray[np.float64]:
    result = np.asarray(value, dtype=np.float64)
    if result.ndim == 0:
        result = np.array((0.0, 0.0, float(result)))
    if result.shape != (3,) or not np.all(np.isfinite(result)):
        raise ValueError("floor impulse must be a finite scalar z or three-vector")
    return result


class ForceReference:
    """Reference samples matched by frame AND exact integration interval, without fallback."""

    def __init__(self, path: str | Path, metadata: dict[str, Any]) -> None:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
        reference_metadata = document["metadata"]
        for candidate in (metadata, reference_metadata):
            method = str(candidate.get("floor_force_method", "")).lower()
            if "partial" in method or "estimate" in method:
                raise ValueError("partial or estimated floor force cannot define a formal reference MSE")
        for key in _REFERENCE_KEYS:
            if key not in metadata or key not in reference_metadata:
                raise ValueError(f"missing reference protocol metadata: {key}")
            if metadata[key] != reference_metadata[key]:
                raise ValueError(f"incompatible reference protocol: {key}")
        self.samples: dict[int, dict[str, Any]] = {}
        for row in document["samples"]:
            frame = int(row["frame"])
            if frame in self.samples:
                raise ValueError(f"duplicate reference frame: {frame}")
            self.samples[frame] = row

    def force(self, frame: int, start: float, end: float) -> float:
        """Return vertical force only after exact interval verification."""
        if frame not in self.samples:
            raise ValueError(f"missing reference frame: {frame}")
        row = self.samples[frame]
        if row["time_start_s"] != start or row["time_end_s"] != end:
            raise ValueError(f"incompatible reference time interval for frame {frame}")
        force = float(row["floor_force_N"])
        if not np.isfinite(force):
            raise ValueError("reference force is nonfinite")
        return force


class FluidMetricsRecorder:
    """Write JSON SI metrics and optionally compare against a strictly compatible reference."""

    def __init__(
        self,
        output_path: str | Path | None,
        metadata: dict[str, Any],
        reference_path: str | Path | None = None,
        flush_every: int = 1,
    ) -> None:
        if flush_every < 1:
            raise ValueError("flush_every must be >= 1")
        self.flush_every = int(flush_every)
        self.output_path: Path | None = None if output_path is None else Path(output_path)
        self.journal_path = None if self.output_path is None else self.output_path.with_suffix(self.output_path.suffix + ".jsonl")
        if self.journal_path is not None:
            self.journal_path.parent.mkdir(parents=True, exist_ok=True)
            self.journal_path.write_text("", encoding="utf-8")
        self.metadata: dict[str, Any] = json.loads(json.dumps(metadata, allow_nan=False))
        self.reference: ForceReference | None = (
            None if reference_path is None else ForceReference(reference_path, self.metadata)
        )
        self.samples: list[dict[str, Any]] = []
        self._force_cache: dict[int, tuple[float, float, list[float], dict[str, Any]]] = {}
        self._squared_errors: list[float] = []
        # Reset any stale full JSON from a previous run; JSONL is the per-frame journal.
        self.close()

    def compute_floor_force_mse(
        self,
        frame: int,
        start: float,
        end: float,
        impulse: ArrayLike,
    ) -> dict[str, Any]:
        """Compute vertical frame-average force and an idempotent per-frame reference MSE."""
        start, end = float(start), float(end)
        if not np.isfinite(start) or not np.isfinite(end) or end <= start:
            raise ValueError("force interval must be finite with end > start")
        vector = _impulse(impulse).tolist()
        if frame in self._force_cache:
            old_start, old_end, old_vector, result = self._force_cache[frame]
            if (start, end, vector) != (old_start, old_end, old_vector):
                raise ValueError("frame was already measured with different impulse or interval")
            return dict(result)
        force = np.asarray(vector) / (end - start)
        result: dict[str, Any] = {
            "floor_impulse_ns": vector,
            "floor_force_n": force.tolist(),
            "floor_force_N": float(force[2]),
            "frame_sq_error_N2": None,
            "mean_mse_N2": None,
        }
        if self.reference is not None:
            reference_force = self.reference.force(frame, start, end)
            error = (float(force[2]) - reference_force) ** 2
            self._squared_errors.append(error)
            result.update(
                {
                    "reference_floor_force_N": reference_force,
                    "frame_sq_error_N2": error,
                    "mean_mse_N2": float(np.mean(self._squared_errors)),
                }
            )
        self._force_cache[frame] = (start, end, vector, dict(result))
        return result

    def record(
        self,
        frame: int,
        start: float,
        end: float,
        floor_impulse: ArrayLike | None,
        volume: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Append one sample; repeating or overwriting an emitted frame is an error."""
        if any(row["frame"] == frame for row in self.samples):
            raise ValueError(f"duplicate output frame: {frame}")
        if not np.isfinite(start) or not np.isfinite(end) or end <= start:
            raise ValueError("record interval must be finite with end > start")
        row: dict[str, Any] = dict(volume)
        if extra:
            if set(row).intersection(extra):
                raise ValueError("extra fields overlap volume metrics")
            row.update(extra)
        reserved = {"frame", "time_start_s", "time_end_s", "floor_force_N", "floor_impulse_ns", "floor_force_n"}
        if reserved.intersection(row):
            raise ValueError("volume/extra fields overlap reserved metrics")
        if floor_impulse is not None:
            row.update(self.compute_floor_force_mse(frame, start, end, floor_impulse))
        row.update(frame=int(frame), time_start_s=float(start), time_end_s=float(end))
        # Check serializability/finiteness before updating history or the output file.
        json.dumps(row, allow_nan=False)
        self.samples.append(row)
        if self.journal_path is not None:
            with self.journal_path.open("a", encoding="utf-8") as journal:
                journal.write(json.dumps(row, allow_nan=False) + "\n")
        if len(self.samples) % self.flush_every == 0:
            self.close()
        return dict(row)

    def close(self) -> None:
        """Persist current samples, including an empty run; repeated calls are harmless."""
        if self.output_path is not None:
            self.output_path.parent.mkdir(parents=True, exist_ok=True)
            self.output_path.write_text(
                json.dumps({"metadata": self.metadata, "samples": self.samples}, indent=2, allow_nan=False) + "\n",
                encoding="utf-8",
            )


def collect_floor_contact_metrics(
    impulses_on_collider: ArrayLike,
    collider_ids: ArrayLike,
    collider_body_ids: ArrayLike,
    normals: ArrayLike,
) -> dict[str, Any]:
    """Select static upward contacts; report omitted mixed normals separately.

    The public solver collector already returns physical N*s. Negate once to
    obtain impulses on fluid; no extra voxel-volume or timestep multiplication.
    """
    impulse = -np.asarray(impulses_on_collider, dtype=np.float64)
    ids = np.asarray(collider_ids, dtype=np.int64)
    body_map = np.asarray(collider_body_ids, dtype=np.int64)
    normal = np.asarray(normals, dtype=np.float64)
    if impulse.shape != (len(ids), 3) or normal.shape != impulse.shape:
        raise ValueError("contact arrays have incompatible shapes")
    if not np.all(np.isfinite(impulse)) or not np.all(np.isfinite(normal)):
        raise ValueError("nonfinite contact observations")
    valid = (ids >= 0) & (ids < len(body_map))
    static = np.zeros(len(ids), dtype=bool)
    static[valid] = body_map[ids[valid]] == -1
    length = np.linalg.norm(normal, axis=1)
    unit = normal / np.maximum(length[:, None], 1e-30)
    floor = static & (unit[:, 2] > 1 - 1e-5) & (length > 1e-12)
    mixed = static & (np.max(np.abs(unit), axis=1) <= 1 - 1e-5)
    return {
        "solved_floor_impulse_on_fluid": impulse[floor].sum(axis=0).tolist(),
        "solved_impulse_on_fluid": impulse.sum(axis=0).tolist(),
        "mixed_static_impulse_on_fluid": impulse[mixed].sum(axis=0).tolist(),
        "mixed_static_contact_count": int(np.count_nonzero(mixed & (np.linalg.norm(impulse, axis=1) > 1e-15))),
        "unmapped_impulse_on_fluid": impulse[~valid].sum(axis=0).tolist(),
    }


def floor_pressure_estimate(impulses_on_collider, positions, collider_ids, collider_body_ids, normals,
                            particles, active, radii, voxel_size, duration, projection_impulses=None, projection_positions=None,
                            *, outside_floor_impulses=None, outside_floor_positions=None):
    """Estimate area-averaged normal load from solved, SDF-classified, and tank-clamp impulses."""
    if duration <= 0 or voxel_size <= 0:
        raise ValueError("duration and voxel size must be positive")
    impulse = -np.asarray(impulses_on_collider, dtype=np.float64)
    xyz = np.asarray(positions, dtype=np.float64)
    ids = np.asarray(collider_ids, dtype=np.int64)
    bodies = np.asarray(collider_body_ids, dtype=np.int64)
    normal = np.asarray(normals, dtype=np.float64)
    if impulse.shape != (len(ids), 3) or xyz.shape != impulse.shape or normal.shape != impulse.shape:
        raise ValueError("contact arrays have incompatible shapes")
    if not np.isfinite(impulse).all() or not np.isfinite(xyz).all() or not np.isfinite(normal).all():
        raise ValueError("nonfinite contact observations")
    valid = (ids >= 0) & (ids < len(bodies))
    static = np.zeros(len(ids), dtype=bool)
    static[valid] = bodies[ids[valid]] == -1
    length = np.linalg.norm(normal, axis=1)
    floor = static & (normal[:, 2] / np.maximum(length, 1e-30) > 1 - 1e-5) & (length > 1e-12)
    cell = np.floor(xyz[:, :2] / 0.1).astype(np.int64)
    inside = (cell[:, 0] >= 0) & (cell[:, 0] < 32) & (cell[:, 1] >= 0) & (cell[:, 1] < 32)
    outside_impulse = float(impulse[floor & ~inside, 2].sum())
    floor &= inside
    grid = np.zeros((32, 32), dtype=np.float64)
    np.add.at(grid, (cell[floor, 1], cell[floor, 0]), impulse[floor, 2])
    points = np.asarray(particles, dtype=np.float64)
    mask = np.asarray(active, dtype=bool).copy()
    radius = np.asarray(radii, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or mask.shape != (len(points),):
        raise ValueError("particle arrays have incompatible shapes")
    radius = np.broadcast_to(radius, (len(points),))
    if not np.isfinite(points).all() or not np.isfinite(radius).all() or np.any(radius < 0):
        raise ValueError("invalid particle observations")
    pcell = np.floor(points[:, :2] / 0.1).astype(np.int64)
    mask &= (points[:, 2] >= -radius) & (points[:, 2] <= voxel_size + radius)
    mask &= (pcell[:, 0] >= 0) & (pcell[:, 0] < 32) & (pcell[:, 1] >= 0) & (pcell[:, 1] < 32)
    wet = np.zeros((32, 32), dtype=bool)
    wet[pcell[mask, 1], pcell[mask, 0]] = True
    # Preserve recorded floor contacts even when signed impulses within
    # one cell cancel; their net pressure is 0 Pa rather than NA.
    wet[cell[floor, 1], cell[floor, 0]] = True
    if projection_impulses is not None:
        projected_impulse = np.asarray(projection_impulses, dtype=np.float64)
        if projected_impulse.shape != (len(points),) or not np.isfinite(projected_impulse).all():
            raise ValueError("invalid floor projection impulses")
        projected = (projected_impulse != 0) & np.asarray(active, dtype=bool)
        projection_points = points if projection_positions is None else np.asarray(projection_positions, dtype=np.float64)
        if projection_points.shape != points.shape or not np.isfinite(projection_points).all():
            raise ValueError("invalid floor projection positions")
        projection_cell = np.floor(projection_points[:, :2] / 0.1).astype(np.int64)
        pinside = (projection_cell[:, 0] >= 0) & (projection_cell[:, 0] < 32) & (projection_cell[:, 1] >= 0) & (projection_cell[:, 1] < 32)
        outside_impulse += float(projected_impulse[projected & ~pinside].sum())
        projected &= pinside
        wet[projection_cell[projected, 1], projection_cell[projected, 0]] = True
        np.add.at(grid, (projection_cell[projected, 1], projection_cell[projected, 0]), projected_impulse[projected])
    if outside_floor_impulses is not None or outside_floor_positions is not None:
        if outside_floor_impulses is None or outside_floor_positions is None:
            raise ValueError("outside floor projection impulses and positions must be supplied together")
        floor_extra = np.asarray(outside_floor_impulses, dtype=np.float64)
        xyz_extra = np.asarray(outside_floor_positions, dtype=np.float64)
        if floor_extra.ndim != 2 or floor_extra.shape[1] != 3 or xyz_extra.shape != floor_extra.shape:
            raise ValueError("invalid project_outside floor impulse shapes")
        if not np.isfinite(floor_extra).all() or not np.isfinite(xyz_extra).all():
            raise ValueError("nonfinite project_outside floor impulses")
        ec = np.floor(xyz_extra[:, :2] / 0.1).astype(np.int64)
        ein = (ec[:, 0] >= 0) & (ec[:, 0] < 32) & (ec[:, 1] >= 0) & (ec[:, 1] < 32)
        outside_impulse += float(floor_extra[~ein, 2].sum())
        np.add.at(grid, (ec[ein, 1], ec[ein, 0]), floor_extra[ein, 2])
        wet[ec[ein, 1], ec[ein, 0]] = True
    pressure = grid / (0.01 * duration)
    values = [[float(pressure[y, x]) if wet[y, x] else None for x in range(32)] for y in range(32)]
    return {
        "floor_pressure_pa": values,
        "pressure_method": "solved_floor_contact_plus_project_outside_static_floor_velocity_impulse_plus_tank_floor_projection_per_area_per_frame",
        "pressure_wet_method": "active_particle_center_in_cell_and_minus_radius_to_voxel_plus_radius_or_floor_impulse",
        "pressure_wet_voxel_size_m": float(voxel_size),
        "pressure_out_of_grid_impulse_ns": outside_impulse,
        "pressure_wet_cell_count": int(wet.sum()),
        "pressure_unreported_dry_cell_impulse_ns": float(grid[~wet].sum()),
    }


class PressureReference:
    """Compare matching frame and integration interval against pressure samples."""

    def __init__(self, path):
        document = json.loads(Path(path).read_text(encoding="utf-8"))
        self.samples: dict[int, dict[str, Any]] = {}
        for row in document["samples"]:
            frame = int(row["frame"])
            if frame in self.samples:
                raise ValueError(f"duplicate pressure reference frame: {frame}")
            self.samples[frame] = row

    def compare(self, frame, start, end, pressure):
        if frame not in self.samples:
            raise ValueError(f"missing pressure reference frame: {frame}")
        row = self.samples[frame]
        if row["time_start_s"] != start or row["time_end_s"] != end:
            raise ValueError(f"incompatible pressure reference time interval for frame {frame}")
        ref = row["floor_pressure_pa"]
        if len(ref) != 32 or any(len(line) != 32 for line in ref):
            raise ValueError("pressure reference must be a 32x32 array")
        reference_values = []
        current_values = []
        for y in range(32):
            for x in range(32):
                if ref[y][x] is not None and pressure[y][x] is not None:
                    value = float(ref[y][x])
                    current = float(pressure[y][x])
                    if not np.isfinite(value) or not np.isfinite(current):
                        raise ValueError("nonfinite pressure sample")
                    reference_values.append(value)
                    current_values.append(current)
        return {
            "pressure_spatial_mean_absolute_error_Pa": (
                abs(float(np.mean(current_values)) - float(np.mean(reference_values))) if reference_values else None
            ),
            "pressure_common_valid_point_count": len(reference_values),
        }
