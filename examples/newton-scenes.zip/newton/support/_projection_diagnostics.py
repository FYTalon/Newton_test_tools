"""Read-only classification of implicit-MPM project_outside velocity impulses.

This observer runs after the solver projection on a copy of its pre-projection
particle positions, using the exact same collision_sdf and collider state.
It never writes solver positions, velocities or history. Only contacts with
an unambiguously upward *static* collision normal are assigned to the floor.
The resulting impulse is a velocity correction, not the positional projection
reaction (which remains unmeasured).
"""
from __future__ import annotations

import numpy as np
import warp as wp

from newton._src.solvers.implicit_mpm.rasterized_collisions import Collider, collision_sdf


@wp.kernel
def _projection_source_labels(
    positions: wp.array[wp.vec3],
    flags: wp.array[wp.int32],
    masses: wp.array[float],
    particle_environment: wp.array[int],
    collider: Collider,
    body_q: wp.array[wp.transform],
    body_qd: wp.array[wp.spatial_vector],
    body_q_prev: wp.array[wp.transform],
    dt: float,
    active_bit: int,
    labels: wp.array[int],
):
    i = wp.tid()
    labels[i] = -1
    if (flags[i] & active_bit) == 0 or masses[i] == 0.0:
        return
    environment = -2  # same _ALL_COLLIDER_WORLDS sentinel as project_outside_collider
    if particle_environment:
        environment = particle_environment[i]
    sdf, normal, velocity, collider_id, material_id = collision_sdf(
        positions[i], environment, collider, body_q, body_qd, body_q_prev, dt
    )
    if collider_id < 0:
        return
    sdf_end = sdf - wp.dot(velocity, normal) * dt + collider.material_projection_threshold[material_id]
    if sdf_end >= 0.0:
        return
    if collider.collider_body_index[collider_id] >= 0:
        labels[i] = 2  # dynamic collider; not part of the static floor
    elif wp.length(normal) > 1.0e-12 and normal[2] / wp.length(normal) > 1.0 - 1.0e-5:
        labels[i] = 1  # static surface, unambiguous upward floor normal
    else:
        labels[i] = 0  # side wall, corner, or ambiguous static normal


def classify_projection_sources(solver, state, positions_before: np.ndarray, dt: float) -> np.ndarray:
    """Replay *only the SDF query* with pre-projection positions and current colliders."""
    device = state.particle_q.device
    positions = wp.array(np.asarray(positions_before, dtype=np.float32), dtype=wp.vec3, device=device)
    labels = wp.empty(len(positions_before), dtype=int, device=device)
    wp.launch(
        _projection_source_labels,
        dim=len(positions_before),
        inputs=[
            positions,
            solver._mpm_model.particle_flags,
            solver.model.particle_mass,
            solver._particle_environment,
            solver._mpm_model.collider,
            state.body_q,
            state.body_qd if solver.collider_velocity_mode == "forward" else None,
            solver._last_step_data.body_q_prev if solver.collider_velocity_mode == "backward" else None,
            float(dt),
            int(1),
        ],
        outputs=[labels],
        device=device,
    )
    return labels.numpy()


def projection_impulse_ledger(
    positions_before: np.ndarray,
    velocities_before: np.ndarray,
    velocities_after: np.ndarray,
    masses: np.ndarray,
    active: np.ndarray,
    labels: np.ndarray,
) -> dict:
    """Partition observed m*delta(v) by source; never assign unknowns to floor."""
    before = np.asarray(velocities_before, dtype=np.float64)
    after = np.asarray(velocities_after, dtype=np.float64)
    xyz = np.asarray(positions_before, dtype=np.float64)
    mass = np.asarray(masses, dtype=np.float64)
    active = np.asarray(active, dtype=bool)
    labels = np.asarray(labels, dtype=np.int32)
    n = len(mass)
    if before.shape != (n, 3) or after.shape != (n, 3) or xyz.shape != (n, 3):
        raise ValueError("project_outside inputs have mismatched particle shapes")
    if active.shape != (n,) or labels.shape != (n,) or np.any(~np.isin(labels, [-1, 0, 1, 2])):
        raise ValueError("invalid projection source labels")
    if not all(np.isfinite(a).all() for a in (before, after, xyz, mass)):
        raise ValueError("non-finite projection diagnostic data")
    impulse = mass[:, None] * (after - before)
    impulse[~active] = 0.0
    floor = active & (labels == 1)
    groups = {"floor": floor, "other_static": active & (labels == 0),
              "body": active & (labels == 2), "unassigned": active & (labels == -1)}
    totals = {name: impulse[mask].sum(axis=0) for name, mask in groups.items()}
    total = impulse.sum(axis=0)
    residual = total - sum(totals.values(), np.zeros(3))
    return {
        "floor_positions": xyz[floor],
        "floor_impulses": impulse[floor],
        "total_impulse_on_fluid": total,
        "totals": totals,
        "counts": {name: int(mask.sum()) for name, mask in groups.items()},
        "unassigned_nonzero_count": int(np.count_nonzero(
            (labels == -1) & active & (np.linalg.norm(impulse, axis=1) > 1.0e-12)
        )),
        "partition_residual": residual,
    }
