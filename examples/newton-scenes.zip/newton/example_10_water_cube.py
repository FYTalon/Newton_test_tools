
"""Water-like MPM dam break interacting with a single rigid cube.

The scene follows the documented dam-break setup: an open 3.2 m x 3.2 m tank (floor at
z = 0, interior spanning [0, 3.2] x [0, 3.2]) holds a
dam-break water column spanning x = [0, 1.28], y = [0, 3.2], z = [0.01, 2.56], and a single
buoyant cube (side length 0.50 m, total mass 125 kg) centered at (1.6, 1.6, 4.0). The cube
starts upright with its edges parallel to the world axes. It is the only rigid body and is
dynamic from the first frame: there is no release gating, so it falls and interacts with
the dam-break front.

The water is rendered as particles and the tank walls render semi-transparent so the fluid
inside stays visible. The water material and tank collider follow
``example_mpm_water_dam_break``; the two-way rigid coupling (impulse collection against the
MPM collider grid, with the previously applied forces subtracted before the MPM step)
follows ``example_mpm_twoway_coupling``.

Command: python -m newton.examples.mpm.example_mpm_water_dam_single_box

By default the scenario runs 600 frames headlessly with five tank planes and writes
the partial floor-pressure estimate to runs/newton_floor_pressure.json. Optional
--floor-force-mse and --incompressibility expose frame-average measured floor load
and dynamically expanded saturated CIC effective volume. --metrics-output selects the JSON file.
Floor attribution remains partial; partial force references are rejected.
"""

from __future__ import annotations

import hashlib
import json
import math
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import warp as wp

import newton
import newton.examples
from support._fluid_metrics import (
    CICEffectiveVolume,
    FluidMetricsRecorder,
    PressureReference,
    collect_floor_contact_metrics,
    floor_pressure_estimate,
)
from support._projection_diagnostics import (
    classify_projection_sources,
    projection_impulse_ledger,
)
from newton.solvers import SolverImplicitMPM


@wp.kernel
def compute_body_forces(
    dt: float,
    collider_ids: wp.array[int],
    collider_impulses: wp.array[wp.vec3],
    collider_impulse_pos: wp.array[wp.vec3],
    body_ids: wp.array[int],
    body_q: wp.array[wp.transform],
    body_com: wp.array[wp.vec3],
    body_f: wp.array[wp.spatial_vector],
):
    """Compute forces applied by the water to rigid bodies.

    Sum the impulses applied on each mpm grid node and convert to
    forces and torques at the body's center of mass.
    """

    i = wp.tid()

    cid = collider_ids[i]
    if cid >= 0 and cid < body_ids.shape[0]:
        body_index = body_ids[cid]
        if body_index == -1:
            return

        f_world = collider_impulses[i] / dt

        X_wb = body_q[body_index]
        X_com = body_com[body_index]
        r = collider_impulse_pos[i] - wp.transform_point(X_wb, X_com)
        wp.atomic_add(body_f, body_index, wp.spatial_vector(f_world, wp.cross(r, f_world)))


@wp.kernel
def subtract_body_force(
    dt: float,
    body_q: wp.array[wp.transform],
    body_qd: wp.array[wp.spatial_vector],
    body_f: wp.array[wp.spatial_vector],
    body_inv_inertia: wp.array[wp.mat33],
    body_inv_mass: wp.array[float],
    body_q_res: wp.array[wp.transform],
    body_qd_res: wp.array[wp.spatial_vector],
):
    """Update the rigid bodies velocity to remove the forces applied by water at the last step.

    This is necessary to compute the total impulses that are required to enforce the complementarity-based
    frictional contact boundary conditions.
    """

    body_id = wp.tid()

    # Remove previously applied force
    f = body_f[body_id]
    delta_v = dt * body_inv_mass[body_id] * wp.spatial_top(f)
    r = wp.transform_get_rotation(body_q[body_id])

    delta_w = dt * wp.quat_rotate(r, body_inv_inertia[body_id] * wp.quat_rotate_inv(r, wp.spatial_bottom(f)))

    body_q_res[body_id] = body_q[body_id]
    body_qd_res[body_id] = body_qd[body_id] - wp.spatial_vector(delta_v, delta_w)


@wp.kernel
def project_inside_tank(
    positions: wp.array[wp.vec3],
    velocities: wp.array[wp.vec3],
    particle_flags: wp.array[wp.int32],
    center: wp.vec3,
    half_extents: wp.vec3,
    floor_height: float,
    projection_threshold: float,
):
    i = wp.tid()
    if (particle_flags[i] & newton.ParticleFlags.ACTIVE) == 0:
        return

    pos = positions[i]
    vel = velocities[i]
    min_x = center[0] - half_extents[0] - projection_threshold
    max_x = center[0] + half_extents[0] + projection_threshold
    min_y = center[1] - half_extents[1] - projection_threshold
    max_y = center[1] + half_extents[1] + projection_threshold
    min_z = floor_height - projection_threshold

    if pos[0] < min_x:
        pos[0] = min_x
        vel[0] = wp.max(vel[0], 0.0)
    elif pos[0] > max_x:
        pos[0] = max_x
        vel[0] = wp.min(vel[0], 0.0)
    if pos[1] < min_y:
        pos[1] = min_y
        vel[1] = wp.max(vel[1], 0.0)
    elif pos[1] > max_y:
        pos[1] = max_y
        vel[1] = wp.min(vel[1], 0.0)
    if pos[2] < min_z:
        pos[2] = min_z
        vel[2] = wp.max(vel[2], 0.0)

    positions[i] = pos
    velocities[i] = vel


class Example:
    def __init__(self, viewer, args):
        if args.floor_pressure is not None and not args.tank_planes:
            raise ValueError("--floor-pressure requires --tank-planes so the floor is at z=0")
        self.fps = args.fps
        self.frame_dt = 1.0 / self.fps
        self.sim_time = 0.0
        self.sim_substeps = args.substeps
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.viewer = viewer
        self.metrics_snapshots: Path | None = Path(args.metrics_snapshots) if args.metrics_snapshots else None
        self.metrics_frame: int = 0
        self.metrics_gravity: tuple[float, float, float] = tuple(args.gravity)
        self.metrics_density: float = args.density
        self._report_floor: bool = args.floor_force_mse is not None
        self._report_volume: bool = bool(args.incompressibility)
        self._report_pressure: bool = args.floor_pressure is not None
        self._pressure_reference: PressureReference | None = (
            PressureReference(args.floor_pressure) if args.floor_pressure else None
        )
        self._observe_boundaries: bool = self._report_floor or self._report_pressure or self.metrics_snapshots is not None
        self._metric_recorder: FluidMetricsRecorder | None = None
        self._volume_diagnostic: CICEffectiveVolume | None = None
        self._frame_floor_impulse: float = 0.0
        self._frame_metric_extra: dict[str, Any] = {}
        self._metric_step_seconds: float = 0.0
        self._requested_metric_frames: int = args.num_frames
        self.metrics_protocol: str = "five_planes" if args.tank_planes else "original_beveled_mesh"
        if self.metrics_snapshots is not None:
            self.metrics_snapshots.mkdir(parents=True, exist_ok=True)

        self.tank_extents = np.asarray(args.tank_extents, dtype=np.float32)
        self.tank_center_xy = (float(args.tank_center[0]), float(args.tank_center[1]))

        # ------------------------------------------------------------------
        # Rigid side: one free cube (released at start) + the tank
        # ------------------------------------------------------------------
        builder = newton.ModelBuilder()
        cube_half_extent = args.cube_half_extent
        cube_volume = (2.0 * cube_half_extent) ** 3
        if cube_half_extent <= 0.0 or args.cube_mass <= 0.0:
            raise ValueError("cube half extent and total mass must be positive")
        cube_density = args.cube_mass / cube_volume
        cube_tilt = math.radians(args.cube_tilt_degrees)
        cube_rot_x = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), cube_tilt)
        cube_rot_z = wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), 0.5 * cube_tilt)
        cube_pos = wp.vec3(args.cube_pos[0], args.cube_pos[1], args.cube_pos[2])
        self.cube_initial_z = float(args.cube_pos[2])
        self.cube_body = builder.add_body(
            xform=wp.transform(p=cube_pos, q=wp.mul(cube_rot_z, cube_rot_x)),
            # The shape supplies the requested total mass and homogeneous-box
            # inertia; do not add a point mass at the center of mass.
            mass=0.0,
        )
        builder.add_shape_box(
            self.cube_body,
            hx=cube_half_extent,
            hy=cube_half_extent,
            hz=cube_half_extent,
            cfg=newton.ModelBuilder.ShapeConfig(density=cube_density, mu=args.cube_friction),
        )
        self._add_tank(builder, args)
        self.model = builder.finalize()
        self.model.set_gravity(args.gravity)

        # ------------------------------------------------------------------
        # Water side: water-like MPM material emitted as a dam-break column
        # ------------------------------------------------------------------
        water_builder = newton.ModelBuilder()
        SolverImplicitMPM.register_custom_attributes(water_builder)
        self.initial_water_max_x = self._emit_water(water_builder, args)
        self.water_model = water_builder.finalize()
        self.water_model.set_gravity(args.gravity)
        self.water_model.mpm.friction.fill_(args.friction)
        self.water_model.mpm.tensile_yield_ratio.fill_(args.tensile_yield_ratio)
        self.water_model.mpm.viscosity.fill_(args.viscosity)

        mpm_config = SolverImplicitMPM.Config()
        mpm_config.voxel_size = args.voxel_size
        mpm_config.max_iterations = args.max_iterations
        mpm_config.tolerance = args.tolerance
        mpm_config.warmstart_mode = args.warmstart_mode
        mpm_config.strain_basis = args.strain_basis
        mpm_config.collider_basis = args.collider_basis
        mpm_config.velocity_basis = args.velocity_basis
        self.solver = SolverImplicitMPM(self.water_model, config=mpm_config)

        self.projection_threshold = (
            args.projection_threshold if args.projection_threshold is not None else 0.25 * args.voxel_size
        )
        self.floor_height = 0.0 if args.tank_planes else -args.wall_thickness
        if self.projection_threshold < 0.0:
            raise ValueError("projection_threshold must be non-negative")
        # The cube, tank, and ground plane all live on the rigid model; the MPM
        # solver reads them (including the dynamic cube) as colliders from there.
        # Per-collider lists have one entry per collider *source*: all static
        # shapes share one entry, plus one entry per dynamic body.
        shape_flags = self.model.shape_flags.numpy()
        shape_body = self.model.shape_body.numpy()
        colliding = (shape_flags & int(newton.ShapeFlags.COLLIDE_PARTICLES)) != 0
        static_entry_count = 1 if np.any(colliding & (shape_body < 0)) else 0
        dynamic_body_count = len(np.unique(shape_body[colliding & (shape_body >= 0)]))
        self.solver.setup_collider(
            model=self.model,
            collider_projection_threshold=[self.projection_threshold] * (static_entry_count + dynamic_body_count),
        )

        # ------------------------------------------------------------------
        # Rigid solver and coupling state
        # ------------------------------------------------------------------
        self.rigid_solver = newton.solvers.SolverMuJoCo(self.model, use_mujoco_contacts=False, njmax=100)

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()
        self.collision_pipeline = newton.CollisionPipeline(self.model)
        self.contacts = self.collision_pipeline.contacts()

        self.water_state = self.water_model.state()
        # Body buffers so the MPM solver can read the dynamic cube's collider
        # state (filled by subtract_body_force with the pre-force velocities).
        # Initial collision projection already queries dynamic collider transforms.
        # Initialize them before that query rather than reading uninitialized buffers.
        self.water_state.body_q = wp.clone(self.state_0.body_q)
        self.water_state.body_qd = wp.clone(self.state_0.body_qd)
        self.water_state.body_f = wp.zeros_like(self.state_0.body_f)
        self.water_state.mpm.particle_Jp.fill_(1.0)
        self.solver.project_outside(self.water_state, self.water_state, self.sim_dt)

        # Additional buffers for tracking two-way coupling forces
        max_nodes = 1 << 20
        self.collider_impulses = wp.zeros(max_nodes, dtype=wp.vec3, device=self.model.device)
        self.collider_impulse_pos = wp.zeros(max_nodes, dtype=wp.vec3, device=self.model.device)
        self.collider_impulse_ids = wp.full(max_nodes, value=-1, dtype=int, device=self.model.device)
        self.collect_collider_impulses()

        # Map from collider index to body index
        self.collider_body_id = self.solver.collider_body_index

        # Per-body forces and torques applied by water to rigid bodies
        self.body_water_forces = wp.zeros_like(self.state_0.body_f)

        self.water_colors = wp.full(
            self.water_model.particle_count,
            value=wp.vec3(0.12, 0.42, 0.8),
            dtype=wp.vec3,
            device=self.water_model.device,
        )

        self.viewer.set_model(self.model)
        # Same viewpoint as the WanPhys scenario (its setup_viewer camera
        # arguments); FOV stays at both viewers' default of 45.0 deg.
        self.viewer.set_camera(pos=wp.vec3(7.10, -3.91, 4.47), pitch=-19.2, yaw=138.6)
        self._init_scalar_metrics(args)
        self._write_metrics_snapshot()
        if args.initial_snapshot:
            self._write_metrics_snapshot(Path(args.initial_snapshot))

    def _init_scalar_metrics(self, args) -> None:
        if not (self._report_floor or self._report_volume or self._report_pressure):
            return
        positions = self.water_state.particle_q.numpy()
        masses = self.water_model.particle_mass.numpy()
        active = (self.water_model.particle_flags.numpy() & int(newton.ParticleFlags.ACTIVE)) != 0
        spacing = float(self.solver.voxel_size) if args.diagnostic_h is None else args.diagnostic_h
        self._volume_diagnostic = CICEffectiveVolume(
            positions,
            masses.astype(np.float64) / self.metrics_density,
            spacing,
            origin=args.diagnostic_origin,
            active_mask=active,
            device=self.water_model.device,
            margin_m=args.cic_margin_m,
        )
        digest = hashlib.sha256()
        for array in (positions, masses, self.water_state.particle_qd.numpy()):
            digest.update(np.asarray(array, dtype="<f4").tobytes())
        digest.update(active.astype(np.uint8).tobytes())
        scene = {
            "gravity": list(args.gravity),
            "tank_center": list(args.tank_center),
            "tank_extents": list(args.tank_extents),
            "fps": args.fps,
            "wall_friction": args.wall_friction if args.tank_planes else 0.5,
            "cube_mass": args.cube_mass,
            "tank_geometry": self.metrics_protocol,
            "cube_half_extent": args.cube_half_extent,
            "cube_pos": list(args.cube_pos),
            "cube_tilt_degrees": args.cube_tilt_degrees,
        }
        metadata = {
            "backend": "newton_implicit_mpm",
            "scene_protocol": json.dumps(scene, sort_keys=True),
            "floor_force_method": "partial_implicit_normal_floor_plus_sdf_outside_velocity_plus_tank_projection_v3",
            "floor_force_sign": "upward_on_fluid_equals_downward_load_positive",
            "volume_method": "CIC_saturated_rest_volume_sparse_float64_v2",
            "diagnostic_h_m": float(spacing),
            "diagnostic_origin_m": list(args.diagnostic_origin),
            "total_mass_kg": float(masses.sum(dtype=np.float64)),
            "initial_state_sha256": digest.hexdigest(),
            "initial_cube_center_m": self._cube_center().tolist(),
        }
        output = args.metrics_output or str(
            Path("runs/newton_mpm_water_dam_single_box") / f"metrics_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
        )
        self._metric_recorder = FluidMetricsRecorder(output, metadata, args.floor_force_mse or None, flush_every=args.metrics_flush_every)

    def compute_incompressibility(self) -> dict[str, Any]:
        """Return fixed-lattice CIC effective_volume_m3 and volume_ratio."""
        if not self._report_volume or self._volume_diagnostic is None:
            raise RuntimeError("Pass --incompressibility to enable this diagnostic")
        return self._volume_diagnostic.measure_gpu(
            self.water_state.particle_q, self.water_model.particle_flags, int(newton.ParticleFlags.ACTIVE)
        )

    def compute_floor_force_mse(self, frame: int, start_s: float, end_s: float) -> dict[str, Any]:
        """Return current measured floor load; partial force references are rejected."""
        if not self._report_floor or self._metric_recorder is None:
            raise RuntimeError("Pass --floor-force-mse to enable this diagnostic")
        return self._metric_recorder.compute_floor_force_mse(frame, start_s, end_s, self._frame_floor_impulse)

    def _record_scalar_metrics(self, start_s: float, end_s: float) -> None:
        if self._metric_recorder is None:
            return
        if self._report_floor:
            self.compute_floor_force_mse(self.metrics_frame, start_s, end_s)
        if self._report_pressure:
            pressure = self._frame_metric_extra["floor_pressure_pa"]
            errors = (self._pressure_reference.compare(self.metrics_frame, start_s, end_s, pressure)
                      if self._pressure_reference else {"pressure_spatial_mean_absolute_error_Pa": None,
                                                       "pressure_common_valid_point_count": 0})
            self._frame_metric_extra.update(errors)
        self._frame_metric_extra["cube_center_m"] = self._cube_center().tolist()
        self._frame_metric_extra["physics_step_wall_seconds"] = self._metric_step_seconds
        result = self._metric_recorder.record(
            self.metrics_frame,
            start_s,
            end_s,
            self._frame_floor_impulse if self._report_floor else None,
            self.compute_incompressibility() if self._report_volume else {},
            extra=self._frame_metric_extra,
        )
        prefix = f"[FRAME] newton frame={self.metrics_frame} t={end_s:.6f}s"
        if self._report_pressure:
            pressures = np.asarray(result["floor_pressure_pa"], dtype=float)
            valid = np.isfinite(pressures)
            mean = f"{float(np.mean(pressures[valid])):.6f}" if np.any(valid) else "NA"
            print(f"{prefix} pressure_mean_pa={mean}", flush=True)
        if self._report_volume:
            print(f"{prefix} volume_loss_percent={100.0 * (1.0 - result['volume_ratio']):.6f}", flush=True)

    def finish_metrics(self) -> None:
        """Flush the JSON output, including normal and interrupted headless runs."""
        if self._metric_recorder is not None:
            self._metric_recorder.close()
            samples = self._metric_recorder.samples
            volume_ratios = [row["volume_ratio"] for row in samples if "volume_ratio" in row]
            floor_means = []
            for row in samples:
                if "floor_pressure_pa" not in row:
                    continue
                values = np.asarray(row["floor_pressure_pa"], dtype=float)
                valid = np.isfinite(values)
                if np.any(valid):
                    floor_means.append(float(np.mean(values[valid])))
            measured_seconds = float(sum(row["physics_step_wall_seconds"] for row in samples))
            summary = {
                "backend": "newton_implicit_mpm",
                "completed_frames": len(samples),
                "requested_frames": self._requested_metric_frames,
                "complete": len(samples) == self._requested_metric_frames,
                "status": "complete" if len(samples) == self._requested_metric_frames else "partial",
                "physical_time_s": self.sim_time,
                "mean_volume_loss_percent": float(np.mean([100.0 * (1.0 - r) for r in volume_ratios]))
                if volume_ratios else None,
                "mean_floor_pressure_Pa": float(np.mean(floor_means)) if floor_means else None,
                "floor_pressure_mean_valid_frames": len(floor_means),
                "measured_step_seconds": measured_seconds,
                "measured_fps": len(samples) / measured_seconds if measured_seconds > 0.0 else None,
                "timing_scope": "synchronized simulate calls; includes boundary diagnostics, excludes initialization, frame metric recording, output and rendering; not a pure solver benchmark",
                "metrics_file": str(self._metric_recorder.output_path.resolve()),
            }
            self._metric_recorder.output_path.write_text(
                json.dumps(
                    {"metadata": self._metric_recorder.metadata, "samples": samples, "summary": summary},
                    indent=2,
                    allow_nan=False,
                ) + "\n",
                encoding="utf-8",
            )
            if summary["status"] == "complete":
                for key in ("mean_floor_pressure_Pa", "mean_volume_loss_percent"):
                    value = summary[key]
                    if value is not None:
                        print(f"[SCORE INPUT] newton {key}={value:.6f}", flush=True)
            else:
                print(f"[INCOMPLETE] newton frames={len(samples)}/{self._requested_metric_frames}", flush=True)
            print(f"[DETAIL] newton metrics_file={self._metric_recorder.output_path.resolve()}", flush=True)

    def _cube_center(self) -> np.ndarray:
        """Return world-space center of mass without changing the rigid state."""
        pose = self.state_0.body_q.numpy()[self.cube_body].astype(np.float64)
        local = self.model.body_com.numpy()[self.cube_body].astype(np.float64)
        q = pose[3:] / np.linalg.norm(pose[3:])
        rotated = local + 2.0 * np.cross(q[:3], np.cross(q[:3], local) + q[3] * local)
        return pose[:3] + rotated

    def _write_metrics_snapshot(self, path: Path | None = None, **extra) -> None:
        """Export independent physical observations in SI units, outside graph capture."""
        if path is None and self.metrics_snapshots is None:
            return
        if path is None:
            path = self.metrics_snapshots / f"frame_{self.metrics_frame:06d}.npz"
        path.parent.mkdir(parents=True, exist_ok=True)
        flags = self.water_model.particle_flags.numpy()
        data = {
            "positions": self.water_state.particle_q.numpy(),
            "velocities": self.water_state.particle_qd.numpy(),
            "masses": self.water_model.particle_mass.numpy(),
            "active": (flags & int(newton.ParticleFlags.ACTIVE)) != 0,
            "time": np.asarray(self.sim_time),
            "dt": np.asarray(self.frame_dt),
            "frame": np.asarray(self.metrics_frame),
            "gravity": np.asarray(self.metrics_gravity),
            "density": np.asarray(self.metrics_density),
            "voxel_size": np.asarray(self.solver.voxel_size),
            "protocol": np.asarray(self.metrics_protocol),
        }
        data.update(extra)
        np.savez_compressed(path, **data)

    def _metrics_momentum(self, velocities: np.ndarray) -> np.ndarray:
        masses = self.water_model.particle_mass.numpy().astype(np.float64)
        active = (self.water_model.particle_flags.numpy() & int(newton.ParticleFlags.ACTIVE)) != 0
        return np.sum(masses[active, None] * velocities[active].astype(np.float64), axis=0)

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()

            wp.launch(
                compute_body_forces,
                dim=self.collider_impulse_ids.shape[0],
                inputs=[
                    self.frame_dt,
                    self.collider_impulse_ids,
                    self.collider_impulses,
                    self.collider_impulse_pos,
                    self.collider_body_id,
                    self.state_0.body_q,
                    self.model.body_com,
                    self.state_0.body_f,
                ],
            )
            # Save applied force to subtract later on
            self.body_water_forces.assign(self.state_0.body_f)

            # apply forces to the model
            self.viewer.apply_forces(self.state_0)

            self.collision_pipeline.collide(self.state_0, self.contacts)
            self.rigid_solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)

            # swap states
            self.state_0, self.state_1 = self.state_1, self.state_0

        self.simulate_water()

    def collect_collider_impulses(self):
        collider_impulses, collider_impulse_pos, collider_impulse_ids = self.solver.collect_collider_impulses(
            self.water_state
        )
        self.collider_impulse_ids.fill_(-1)
        n_colliders = min(collider_impulses.shape[0], self.collider_impulses.shape[0])
        self.collider_impulses[:n_colliders].assign(collider_impulses[:n_colliders])
        self.collider_impulse_pos[:n_colliders].assign(collider_impulse_pos[:n_colliders])
        self.collider_impulse_ids[:n_colliders].assign(collider_impulse_ids[:n_colliders])

    def simulate_water(self):
        # Subtract previously applied impulses from body velocities
        if self.water_state.body_q is not None:
            wp.launch(
                subtract_body_force,
                dim=self.water_state.body_q.shape,
                inputs=[
                    self.frame_dt,
                    self.state_0.body_q,
                    self.state_0.body_qd,
                    self.body_water_forces,
                    self.model.body_inv_inertia,
                    self.model.body_inv_mass,
                    self.water_state.body_q,
                    self.water_state.body_qd,
                ],
            )

        if self._observe_boundaries:
            velocities_before = self.water_state.particle_qd.numpy()
        self.solver.step(self.water_state, self.water_state, contacts=None, control=None, dt=self.frame_dt)
        if self._observe_boundaries:
            velocities_solved = self.water_state.particle_qd.numpy()
            impulses, contact_positions, contact_ids = self.solver.collect_collider_impulses(self.water_state)
            self.metrics_step_data: dict = {
                "velocities_before": velocities_before,
                "velocities_solved": velocities_solved,
                "contact_impulses_on_collider": impulses.numpy(),
                "contact_positions": contact_positions.numpy(),
                "contact_ids": contact_ids.numpy(),
                "collider_body_ids": self.solver.collider_body_index.numpy(),
                "contact_normals": self.water_state.collider_normal_field.dof_values.numpy(),
            }
        if self._observe_boundaries:
            outside_positions_before = self.water_state.particle_q.numpy()
        self.solver.project_outside(self.water_state, self.water_state, self.frame_dt)
        if self._observe_boundaries:
            velocities_outside = self.water_state.particle_qd.numpy()
            positions_before_tank_projection = self.water_state.particle_q.numpy()
            active = (self.water_model.particle_flags.numpy() & int(newton.ParticleFlags.ACTIVE)) != 0
            source_labels = classify_projection_sources(
                self.solver, self.water_state, outside_positions_before, self.frame_dt
            )
            outside_ledger = projection_impulse_ledger(
                outside_positions_before,
                velocities_solved,
                velocities_outside,
                self.water_model.particle_mass.numpy(),
                active,
                source_labels,
            )
        wp.launch(
            project_inside_tank,
            dim=self.water_state.particle_count,
            inputs=[
                self.water_state.particle_q,
                self.water_state.particle_qd,
                self.water_model.particle_flags,
                wp.vec3(self.tank_center_xy[0], self.tank_center_xy[1], 0.0),
                wp.vec3(self.tank_extents),
                self.floor_height,
                self.projection_threshold,
            ],
            device=self.water_model.device,
        )

        if self._observe_boundaries:
            velocities_after = self.water_state.particle_qd.numpy()
            self.metrics_step_data.update(
                velocities_outside=velocities_outside,
                project_outside_impulse_on_fluid=(
                    self._metrics_momentum(velocities_outside) - self._metrics_momentum(velocities_solved)
                ),
                tank_projection_impulse_on_fluid=(
                    self._metrics_momentum(velocities_after) - self._metrics_momentum(velocities_outside)
                ),
            )

        if self._report_floor:
            data = self.metrics_step_data
            contacts = collect_floor_contact_metrics(
                data["contact_impulses_on_collider"],
                data["contact_ids"],
                data["collider_body_ids"],
                data["contact_normals"],
            )
            tank = data["tank_projection_impulse_on_fluid"]
            self._frame_floor_impulse = float(
                contacts["solved_floor_impulse_on_fluid"][2]
                + outside_ledger["totals"]["floor"][2]
                + tank[2]
            )
            active = (self.water_model.particle_flags.numpy() & int(newton.ParticleFlags.ACTIVE)) != 0
            masses = self.water_model.particle_mass.numpy()
            gravity = float(masses[active].sum(dtype=np.float64)) * np.asarray(self.metrics_gravity) * self.frame_dt
            residual = self._metrics_momentum(velocities_after) - self._metrics_momentum(velocities_before)
            residual -= (
                gravity
                + np.asarray(contacts["solved_impulse_on_fluid"])
                + data["project_outside_impulse_on_fluid"]
                + tank
            )
            self._frame_metric_extra = {
                **contacts,
                "complete_floor_reaction": False,
                "momentum_residual_Ns": residual.tolist(),
                "project_outside_impulse_on_fluid": data["project_outside_impulse_on_fluid"].tolist(),
                "project_outside_observed_particle_impulse_on_fluid": outside_ledger["total_impulse_on_fluid"].tolist(),
                "project_outside_observation_residual_Ns": (
                    outside_ledger["total_impulse_on_fluid"] - data["project_outside_impulse_on_fluid"]
                ).tolist(),
                "project_outside_floor_impulse_on_fluid": outside_ledger["totals"]["floor"].tolist(),
                "project_outside_other_static_impulse_on_fluid": outside_ledger["totals"]["other_static"].tolist(),
                "project_outside_body_impulse_on_fluid": outside_ledger["totals"]["body"].tolist(),
                "project_outside_unassigned_impulse_on_fluid": outside_ledger["totals"]["unassigned"].tolist(),
                "project_outside_unassigned_nonzero_count": outside_ledger["unassigned_nonzero_count"],
                "project_outside_source_counts": outside_ledger["counts"],
                "project_outside_partition_residual_Ns": outside_ledger["partition_residual"].tolist(),
                "tank_projection_impulse_on_fluid": tank.tolist(),
                "tank_floor_impulse_on_fluid": [0.0, 0.0, float(tank[2])],
                "gravity_impulse_Ns": gravity.tolist(),
            }

        if self._report_pressure:
            data = self.metrics_step_data
            active = (self.water_model.particle_flags.numpy() & int(newton.ParticleFlags.ACTIVE)) != 0
            projection_impulses = (velocities_after[:, 2] - velocities_outside[:, 2]) * self.water_model.particle_mass.numpy()
            self._frame_metric_extra.update(floor_pressure_estimate(
                data["contact_impulses_on_collider"], data["contact_positions"], data["contact_ids"],
                data["collider_body_ids"], data["contact_normals"], self.water_state.particle_q.numpy(),
                active, self.water_model.particle_radius.numpy(), float(self.solver.voxel_size), self.frame_dt,
                projection_impulses, positions_before_tank_projection,
                outside_floor_impulses=outside_ledger["floor_impulses"],
                outside_floor_positions=outside_ledger["floor_positions"],
            ))

        # Save impulses to apply back to rigid bodies
        self.collect_collider_impulses()

    def step(self):
        if self._metric_recorder is not None:
            wp.synchronize_device(self.water_model.device)
            start = time.perf_counter()
            self.simulate()
            wp.synchronize_device(self.water_model.device)
            self._metric_step_seconds = time.perf_counter() - start
        else:
            self.simulate()
        self.sim_time += self.frame_dt
        self.metrics_frame += 1
        if self.metrics_snapshots is not None:
            self._write_metrics_snapshot(**self.metrics_step_data)
        self._record_scalar_metrics(self.sim_time - self.frame_dt, self.sim_time)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)

        self.viewer.log_points(
            "/water",
            points=self.water_state.particle_q,
            radii=self.water_model.particle_radius,
            colors=self.water_colors,
        )

        self.viewer.end_frame()

    def test_final(self):
        # The cube is the only rigid body and is dynamic from the first frame:
        # it must stay above the tank floor and, given enough time, must have
        # fallen well below its release height (a locked-in cube would not).
        newton.examples.test_body_state(
            self.model,
            self.state_0,
            "the cube stays above the tank floor",
            lambda q, qd: q[2] > 0.0,
        )
        if self.sim_time >= 0.5:
            body_q = self.state_0.body_q.numpy()
            cube_z = float(body_q[self.cube_body][2])
            if cube_z > self.cube_initial_z - 0.5:
                raise ValueError(f"The cube was not released at the start (z={cube_z:.3f})")

        voxel_size = self.solver.voxel_size
        # Same 2 * voxel tolerance as the water dam-break example: the slamming
        # column may dip a few particles slightly into the tank floor mesh.
        newton.examples.test_particle_state(
            self.water_state,
            "all water particles are above the ground",
            lambda q, qd: q[2] > -2.0 * voxel_size,
        )
        if self.sim_time >= 0.5:
            positions = self.water_state.particle_q.numpy()
            max_x = float(np.max(positions[:, 0]))
            if max_x < self.initial_water_max_x + 0.1:
                raise ValueError(f"The water column did not spread (max x {max_x:.3f})")

    @staticmethod
    def _emit_water(builder: newton.ModelBuilder, args) -> float:
        if args.particles_per_cell <= 0:
            raise ValueError("particles_per_cell must be positive")

        water_lo = np.asarray(args.emit_lo, dtype=np.float32)
        water_hi = np.asarray(args.emit_hi, dtype=np.float32)
        water_extent = water_hi - water_lo
        if np.any(water_extent <= 0.0):
            raise ValueError("emit_hi must be greater than emit_lo on every axis")

        particle_res = np.ceil(args.particles_per_cell * water_extent / args.voxel_size).astype(int)
        cell_size = water_extent / particle_res
        radius = 0.5 * float(np.max(cell_size))

        builder.add_particle_grid(
            # Center the seeded jittered samples in their initial cells.
            pos=wp.vec3(water_lo + 0.5 * cell_size),
            rot=wp.quat_identity(),
            vel=wp.vec3(0.0),
            dim_x=int(particle_res[0]),
            dim_y=int(particle_res[1]),
            dim_z=int(particle_res[2]),
            cell_x=float(cell_size[0]),
            cell_y=float(cell_size[1]),
            cell_z=float(cell_size[2]),
            mass=float(np.prod(cell_size) * args.density),
            jitter=2.0 * radius,
            radius_mean=radius,
            flags=newton.ParticleFlags.ACTIVE,
        )
        return float(water_hi[0])

    @staticmethod
    def _add_tank(builder: newton.ModelBuilder, args):
        if args.tank_planes:
            half_length, half_width, _ = args.tank_extents
            center_x, center_y = args.tank_center
            min_x, max_x = center_x - half_length, center_x + half_length
            min_y, max_y = center_y - half_width, center_y + half_width
            wall_cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=args.wall_friction, ke=2500.0)
            builder.add_shape_plane((0.0, 0.0, 1.0, 0.0), width=20.0, length=20.0, cfg=wall_cfg, opacity=0.0)
            builder.add_shape_plane((1.0, 0.0, 0.0, -min_x), width=0.0, length=0.0, cfg=wall_cfg, opacity=0.0)
            builder.add_shape_plane((-1.0, 0.0, 0.0, max_x), width=0.0, length=0.0, cfg=wall_cfg, opacity=0.0)
            builder.add_shape_plane((0.0, 1.0, 0.0, -min_y), width=0.0, length=0.0, cfg=wall_cfg, opacity=0.0)
            builder.add_shape_plane((0.0, -1.0, 0.0, max_y), width=0.0, length=0.0, cfg=wall_cfg, opacity=0.0)
            return
        half_length, half_width, half_height = args.tank_extents
        vertices, indices = Example._create_hollow_box_mesh(
            half_length,
            half_width,
            half_height,
            args.wall_thickness,
        )
        tank_center_x, tank_center_y = args.tank_center
        builder.add_shape_mesh(
            body=-1,
            xform=wp.transform(p=wp.vec3(tank_center_x, tank_center_y, 0.0), q=wp.quat_identity()),
            mesh=newton.Mesh(vertices, indices, compute_inertia=False, is_solid=False),
            cfg=newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.5),
            color=(0.32, 0.35, 0.4),
            opacity=0.3,
        )
        builder.add_ground_plane(
            height=-args.wall_thickness,
            cfg=newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.5),
            opacity=0.0,
        )

    @staticmethod
    def _create_hollow_box_mesh(
        hx: float,
        hy: float,
        hz: float,
        thickness: float,
        bevel: float | None = None,
        bevel_segments: int = 4,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Create the open-top hollow-box collider from the S26 dam-break scene."""
        if bevel is None:
            bevel = 0.125 * thickness
        top_z = 2.0 * hz
        vertices = []
        triangles = []

        def add_vertex(x, y, z):
            index = len(vertices)
            vertices.append((x, y, z))
            return index

        def add_quad(a, b, c, d):
            triangles.extend((a, b, c, a, c, d))

        arc = np.linspace(0.0, 0.5 * np.pi, bevel_segments + 1)
        ring_count = bevel_segments + 2
        ring_z = np.empty(ring_count)
        ring_inset = np.empty(ring_count)
        for i in range(bevel_segments + 1):
            ring_z[i] = bevel * (1.0 - np.cos(arc[i]))
            ring_inset[i] = bevel * np.cos(arc[i])
        ring_z[-1] = top_z
        ring_inset[-1] = 0.0

        corners = (
            (-hx + bevel, -hy + bevel, np.pi),
            (hx - bevel, -hy + bevel, 1.5 * np.pi),
            (hx - bevel, hy - bevel, 0.0),
            (-hx + bevel, hy - bevel, 0.5 * np.pi),
        )
        perimeter_count = 4 * (bevel_segments + 1)
        ring_indices = []
        for z, inset in zip(ring_z, ring_inset, strict=True):
            ring = []
            for cx, cy, angle_start in corners:
                for segment in range(bevel_segments + 1):
                    angle = angle_start + segment * (0.5 * np.pi) / bevel_segments
                    ring.append(
                        add_vertex(
                            cx + (bevel - inset) * np.cos(angle),
                            cy + (bevel - inset) * np.sin(angle),
                            z,
                        )
                    )
            ring_indices.append(ring)

        for ring in range(ring_count - 1):
            for i in range(perimeter_count):
                j = (i + 1) % perimeter_count
                add_quad(
                    ring_indices[ring][j],
                    ring_indices[ring][i],
                    ring_indices[ring + 1][i],
                    ring_indices[ring + 1][j],
                )

        floor_center = add_vertex(0.0, 0.0, 0.0)
        for i in range(perimeter_count):
            j = (i + 1) % perimeter_count
            triangles.extend((floor_center, ring_indices[0][i], ring_indices[0][j]))

        outer = (
            add_vertex(-hx - thickness, -hy - thickness, -thickness),
            add_vertex(hx + thickness, -hy - thickness, -thickness),
            add_vertex(hx + thickness, hy + thickness, -thickness),
            add_vertex(-hx - thickness, hy + thickness, -thickness),
            add_vertex(-hx - thickness, -hy - thickness, top_z),
            add_vertex(hx + thickness, -hy - thickness, top_z),
            add_vertex(hx + thickness, hy + thickness, top_z),
            add_vertex(-hx - thickness, hy + thickness, top_z),
        )
        add_quad(outer[0], outer[4], outer[7], outer[3])
        add_quad(outer[1], outer[2], outer[6], outer[5])
        add_quad(outer[0], outer[1], outer[5], outer[4])
        add_quad(outer[3], outer[7], outer[6], outer[2])
        add_quad(outer[0], outer[3], outer[2], outer[1])

        inner_top = ring_indices[-1]
        outer_top = []
        for cx, cy, angle_start in corners:
            for segment in range(bevel_segments + 1):
                angle = angle_start + segment * (0.5 * np.pi) / bevel_segments
                px = cx + bevel * np.cos(angle)
                py = cy + bevel * np.sin(angle)
                outer_top.append(
                    add_vertex(
                        np.clip(px, -hx - thickness, hx + thickness),
                        np.clip(py, -hy - thickness, hy + thickness),
                        top_z,
                    )
                )
        for i in range(perimeter_count):
            j = (i + 1) % perimeter_count
            add_quad(inner_top[i], inner_top[j], outer_top[j], outer_top[i])

        return np.asarray(vertices, dtype=np.float32), np.asarray(triangles, dtype=np.int32)

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.set_defaults(viewer="null", num_frames=600)
        parser.add_argument("--floor-force-mse", nargs="?", const="", default=None, metavar="REFERENCE_JSON")
        parser.add_argument("--floor-pressure", nargs="?", const="", default="", metavar="REFERENCE_JSON")
        parser.add_argument("--no-floor-pressure", action="store_const", const=None, dest="floor_pressure")
        parser.add_argument("--incompressibility", action="store_true")
        parser.add_argument("--metrics-output", type=str, default="runs/newton_floor_pressure.json")
        parser.add_argument("--initial-snapshot", type=str, default=None, help="Write only the initial state NPZ")
        parser.add_argument("--diagnostic-h", type=float, default=0.1, help="CIC diagnostic lattice spacing in metres")
        parser.add_argument("--cic-margin-m", type=float, default=3.0, help="Warp CIC GPU-cache padding in metres; overflow grows the window")
        parser.add_argument("--metrics-flush-every", type=int, default=30, help="Full JSON checkpoint cadence; per-frame JSONL journal remains append-only")
        parser.add_argument("--diagnostic-origin", type=float, nargs=3, default=[0.0, 0.0, 0.0])
        parser.add_argument(
            "--metrics-snapshots",
            type=str,
            default=None,
            help="Export initial and per-frame independent NPZ physical observations to this directory",
        )
        parser.add_argument(
            "--tank-planes",
            action="store_true",
            default=True,
            help="Use the five WanPhys parity planes (default)",
        )
        parser.add_argument("--no-tank-planes", action="store_false", dest="tank_planes")
        parser.add_argument(
            "--wall-friction",
            type=float,
            default=0.5,
            help="Wall friction in --tank-planes mode (use 0 for unambiguous floor reaction tests)",
        )
        parser.add_argument("--fps", type=float, default=60.0)
        # One rigid solve per frame at frame_dt, matching the WanPhys scenario's
        # stepping (the implicit MPM water advance is one full frame_dt step by
        # design; WanPhys substeps its explicit fluid internally for CFL).
        parser.add_argument("--substeps", type=int, default=1)
        # The WanPhys scenario uses gravity -9.81 for the rigid body (-9.8 for
        # the fluid); a single value is applied to both models here.
        parser.add_argument("--gravity", type=float, nargs=3, default=[0.0, 0.0, -9.81])
        parser.add_argument("--voxel-size", "-dx", type=float, default=0.05)
        parser.add_argument("--max-iterations", "-it", type=int, default=50)
        parser.add_argument("--tolerance", "-tol", type=float, default=1.0e-3)
        parser.add_argument("--warmstart-mode", type=str, default="particles")
        parser.add_argument("--strain-basis", "-sb", type=str, default="P0")
        parser.add_argument("--collider-basis", "-cb", type=str, default="pic")
        parser.add_argument("--velocity-basis", "-vb", type=str, default="Q1")
        parser.add_argument(
            "--projection-threshold",
            type=float,
            default=None,
            help="Minimum collider penetration before projection [m] (default: 0.25 * --voxel-size)",
        )
        parser.add_argument("--density", type=float, default=1000.0)
        parser.add_argument("--friction", type=float, default=0.0)
        parser.add_argument("--tensile-yield-ratio", type=float, default=1.0)
        parser.add_argument("--viscosity", type=float, default=0.0)
        parser.add_argument(
            "--particles-per-cell",
            type=int,
            default=2,
            help="Particle samples per MPM cell axis; particle count scales cubically "
            "(2 matches the WanPhys scenario's two particles per 5 cm cell)",
        )
        # Water column and tank match the documented scene: grid_size = 3.2 m,
        # dam_width = 0.4 * 3.2 = 1.28 m, dam_height = 0.8 * 3.2 = 2.56 m.
        parser.add_argument("--emit-lo", type=float, nargs=3, default=[0.0, 0.0, 0.01])
        parser.add_argument("--emit-hi", type=float, nargs=3, default=[1.28, 3.2, 2.56])
        parser.add_argument(
            "--tank-extents",
            type=float,
            nargs=3,
            default=[1.6, 1.6, 2.0],
            help="Tank interior half-extents; its interior spans z=[0, 2 * hz] [m]",
        )
        parser.add_argument(
            "--tank-center",
            type=float,
            nargs=2,
            default=[1.6, 1.6],
            help="Horizontal center of the tank so its interior spans [0, 3.2] x [0, 3.2] like the WanPhys scenario [m]",
        )
        parser.add_argument("--wall-thickness", type=float, default=0.15)
        parser.add_argument(
            "--cube-half-extent",
            type=float,
            default=0.25,
            help="Half extent of the single buoyant cube [m]",
        )
        parser.add_argument("--cube-mass", type=float, default=125.0, help="Total mass of the cube [kg]")
        parser.add_argument(
            "--cube-tilt-degrees",
            type=float,
            default=0.0,
            help="Initial tilt around x (plus half that around z); 0 aligns edges to world axes [degrees]",
        )
        parser.add_argument(
            "--cube-pos",
            type=float,
            nargs=3,
            default=[1.6, 1.6, 4.0],
            help="Initial cube center position; it falls from here when the sim starts",
        )
        parser.add_argument("--cube-friction", type=float, default=0.5, help="Rigid friction of the cube")
        return parser


if __name__ == "__main__":
    # Keep direct benchmark console focused on physical metrics and score inputs.
    # Warnings/errors remain visible; detailed diagnostics are stored in JSON.
    wp.config.log_level = wp.LOG_WARNING
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    try:
        newton.examples.run(example, args)
    finally:
        example.finish_metrics()
