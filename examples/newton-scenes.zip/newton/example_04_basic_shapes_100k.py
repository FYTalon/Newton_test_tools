from pathlib import Path

###########################################################################
# Example Basic Shapes
#
# Shows how to programmatically create a variety of
# collision shapes using the newton.ModelBuilder() API.
# Supports XPBD (default) and VBD solvers.
#
# Command: python example_basic_shapes_100k.py --device cuda:0 --viewer gl
# With VBD: python example_basic_shapes_100k.py --solver vbd --viewer gl
#
#
###########################################################################

import warp as wp
from pxr import Usd

import newton
import newton.examples
import newton.usd


class Example:
    def __init__(self, viewer, args):
        # setup simulation parameters first
        self.fps = 100
        self.frame_dt = 1.0 / self.fps
        self.sim_time = 0.0
        self.sim_substeps = 5
        self.sim_dt = self.frame_dt / self.sim_substeps

        self.viewer = viewer
        self.solver_type = args.solver if hasattr(args, "solver") and args.solver else "xpbd"

        builder = newton.ModelBuilder()

        builder.default_shape_cfg.mu = 1.0  # Friction coefficient

        if self.solver_type == "vbd":
            builder.default_shape_cfg.ke = 1.0e8
            builder.default_shape_cfg.kd = 5.0e5
        else:
            builder.default_shape_cfg.mu_torsional = 0.01  # Contact stiffness
            builder.default_shape_cfg.mu_rolling = 3e-3  # Contact stiffness

        # z height to drop shapes from
        drop_z = 2.0

        # SPHERE
        self.sphere_pos = wp.vec3(0.0, -2.0, drop_z)
        body_sphere = builder.add_body(xform=wp.transform(p=self.sphere_pos, q=wp.quat_identity()), label="sphere")
        builder.add_shape_sphere(body_sphere, radius=0.5)

        # ELLIPSOID (flat disk shape: a=b > c for stability when resting on ground)
        self.ellipsoid_pos = wp.vec3(0.0, -6.0, drop_z)
        body_ellipsoid = builder.add_body(
            xform=wp.transform(p=self.ellipsoid_pos, q=wp.quat_identity()), label="ellipsoid"
        )
        builder.add_shape_ellipsoid(body_ellipsoid, rx=0.5, ry=0.5, rz=0.25)

        # CAPSULE
        self.capsule_pos = wp.vec3(0.0, 0.0, drop_z)
        body_capsule = builder.add_body(xform=wp.transform(p=self.capsule_pos, q=wp.quat_identity()), label="capsule")
        builder.add_shape_capsule(body_capsule, radius=0.3, half_height=0.7)

        # CYLINDER
        self.cylinder_pos = wp.vec3(0.0, -4.0, drop_z)
        body_cylinder = builder.add_body(
            xform=wp.transform(p=self.cylinder_pos, q=wp.quat_identity()), label="cylinder"
        )
        builder.add_shape_cylinder(body_cylinder, radius=0.4, half_height=0.6)

        # BOX
        self.box_pos = wp.vec3(0.0, 2.0, drop_z)
        body_box = builder.add_body(xform=wp.transform(p=self.box_pos, q=wp.quat_identity()), label="box")
        builder.add_shape_box(body_box, hx=0.5, hy=0.35, hz=0.25)

        # MESH (bunny)
        usd_stage = Usd.Stage.Open(str(Path(__file__).resolve().parent / "assets/newton/bunny.usd"))
        demo_mesh = newton.usd.get_mesh(usd_stage.GetPrimAtPath("/root/bunny"))

        scene = builder
        builder = newton.ModelBuilder()
        world_count = 49
        for world in range(world_count):
            builder.begin_world()
            count = (world + 1) * 2381 // world_count - world * 2381 // world_count
            row_offsets = newton.utils.compute_world_offsets(
                count, (1.1, 0.0, 4.0), scene.up_axis
            )
            for index, offset in enumerate(row_offsets):
                row = newton.ModelBuilder()
                row.default_shape_cfg = scene.default_shape_cfg
                row.add_builder(scene)
                with_bunny = index == 45
                self.box2_pos = wp.vec3(0.0, 4.0, drop_z - 0.5)
                body_mesh = row.add_body(
                    xform=wp.transform(p=self.box2_pos, q=wp.quat(0.5, 0.5, 0.5, 0.5)),
                    label="bunny" if with_bunny else "box2",
                )
                if with_bunny:
                    row.add_shape_mesh(body_mesh, mesh=demo_mesh)
                else:
                    row.add_shape_box(body_mesh, hx=0.5, hy=0.35, hz=0.25)

                # CONE
                self.cone_pos = wp.vec3(0.0, 6.0, drop_z)
                body_cone = row.add_body(
                    xform=wp.transform(p=self.cone_pos, q=wp.quat_identity()), label="cone"
                )
                row.add_shape_cone(body_cone, radius=0.45, half_height=0.6)
                layer = int(offset[2] / 4.0)
                direction = 1.0 if layer % 2 else -1.0
                position = wp.vec3(
                    offset[0] + 0.20 * direction,
                    offset[1] + 0.15 * direction,
                    offset[2],
                )
                builder.add_builder(row, wp.transform(position, wp.quat_identity()))
            for x, y, hx, hy in (
                (-4.75, 0.0, 0.25, 7.5),
                (4.75, 0.0, 0.25, 7.5),
                (0.0, -7.25, 5.0, 0.25),
                (0.0, 7.25, 5.0, 0.25),
            ):
                builder.add_shape_box(
                    -1, xform=wp.transform(wp.vec3(x, y, 16.0), wp.quat_identity()),
                    hx=hx, hy=hy, hz=16.0, cfg=scene.default_shape_cfg,
                    color=wp.vec3(0.45, 0.45, 0.45), opacity=0.03,
                )
            builder.end_world()
        builder.add_ground_plane(cfg=scene.default_shape_cfg)

        # Color rigid bodies for VBD solver
        if self.solver_type == "vbd":
            builder.color()

        # finalize model
        self.model = builder.finalize()

        # Create solver based on type
        if self.solver_type == "vbd":
            self.solver = newton.solvers.SolverVBD(
                self.model,
                iterations=5,
                rigid_compliant_alm=True,
            )
        else:
            self.solver = newton.solvers.SolverXPBD(self.model, iterations=5)

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()

        self.collision_pipeline = newton.CollisionPipeline(
            self.model, broad_phase="sap", shape_pairs_max=262_144
        )
        self.contacts = self.collision_pipeline.contacts()

        self.viewer.set_model(self.model)
        self.viewer.set_world_offsets((10.0, 16.0, 0.0))

        # Set camera to view all the shapes
        self.viewer.set_camera(
            pos=wp.vec3(106.5, -21.3, 50.6),
            pitch=-23.0,
            yaw=168.7,
        )
        if hasattr(self.viewer, "camera") and hasattr(self.viewer.camera, "fov"):
            self.viewer.camera.fov = 50.0

        self.capture()

    def capture(self):
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()

            # apply forces to the model
            self.viewer.apply_forces(self.state_0)

            self.collision_pipeline.collide(self.state_0, self.contacts)
            self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)

            # swap states
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        if self.graph:
            wp.capture_launch(self.graph)
        else:
            self.simulate()

        self.sim_time += self.frame_dt

    def test_final(self):
        newton.examples.test_body_state(
            self.model,
            self.state_0,
            "finite body state",
            lambda q, qd: (
                wp.isfinite(wp.transform_get_translation(q))
                and wp.isfinite(wp.transform_get_rotation(q))
                and wp.isfinite(qd)
            ),
        )

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_contacts(self.contacts, self.state_0)
        self.viewer.end_frame()


if __name__ == "__main__":
    # Extend the shared examples parser with a solver choice
    parser = newton.examples.create_parser()
    parser.add_argument(
        "--solver",
        type=str,
        default="xpbd",
        choices=["vbd", "xpbd"],
        help="Solver type: xpbd (default) or vbd",
    )

    viewer, args = newton.examples.init(parser)

    newton.examples.run(Example(viewer, args), args)
